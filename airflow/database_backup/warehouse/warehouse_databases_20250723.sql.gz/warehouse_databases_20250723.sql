--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE dev_user;
ALTER ROLE dev_user WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:0XuMt/4Rmuaso7ZumJS6gQ==$xcses2Rs+QG39gSyRxi1hVMnzjPG5od+uQ3uQ7aI8NE=:g3OcyQjGYC6sJlf3DchqKqjJ/L+ieggDIpTUifmURFY=';

--
-- User Configurations
--


--
-- Role memberships
--

GRANT pg_read_all_stats TO dev_user;




--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

-- Dumped from database version 14.18
-- Dumped by pg_dump version 17.5 (Debian 17.5-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: dev_user
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO dev_user;

--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: dev_user
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

--
-- Database "dtm" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 14.18
-- Dumped by pg_dump version 17.5 (Debian 17.5-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: dtm; Type: DATABASE; Schema: -; Owner: dev_user
--

CREATE DATABASE dtm WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE dtm OWNER TO dev_user;

\connect dtm

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: dwh_fdw; Type: SCHEMA; Schema: -; Owner: dev_user
--

CREATE SCHEMA dwh_fdw;


ALTER SCHEMA dwh_fdw OWNER TO dev_user;

--
-- Name: fdw_metadata; Type: SCHEMA; Schema: -; Owner: dev_user
--

CREATE SCHEMA fdw_metadata;


ALTER SCHEMA fdw_metadata OWNER TO dev_user;

--
-- Name: hr; Type: SCHEMA; Schema: -; Owner: dev_user
--

CREATE SCHEMA hr;


ALTER SCHEMA hr OWNER TO dev_user;

--
-- Name: jira; Type: SCHEMA; Schema: -; Owner: dev_user
--

CREATE SCHEMA jira;


ALTER SCHEMA jira OWNER TO dev_user;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: dev_user
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO dev_user;

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: postgres_fdw; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgres_fdw WITH SCHEMA public;


--
-- Name: EXTENSION postgres_fdw; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgres_fdw IS 'foreign-data wrapper for remote PostgreSQL servers';


--
-- Name: sync_fdw_tables(text, text, text, text); Type: PROCEDURE; Schema: public; Owner: dev_user
--

CREATE PROCEDURE public.sync_fdw_tables(IN local_schema text, IN remote_schema text, IN server_name text, IN metadata_schema text DEFAULT 'fdw_metadata'::text)
    LANGUAGE plpgsql
    AS $_$
DECLARE
    foreign_table TEXT;
    existing_tables TEXT[];
BEGIN

    SELECT array_agg(ft.relname)
    INTO existing_tables
    FROM pg_foreign_table f
    JOIN pg_class ft ON f.ftrelid = ft.oid
    JOIN pg_namespace ns ON ft.relnamespace = ns.oid
    WHERE ns.nspname = local_schema;

    FOR foreign_table IN
        EXECUTE format(
            'SELECT table_name FROM %I.tables WHERE table_schema = %L AND table_type = %L',
            metadata_schema, remote_schema, 'BASE TABLE'
        )
    LOOP
        IF existing_tables IS NULL OR NOT foreign_table = ANY(existing_tables) THEN
            RAISE NOTICE 'Importing new table: %', foreign_table;

            EXECUTE format($f$
                IMPORT FOREIGN SCHEMA %I
                LIMIT TO (%I)
                FROM SERVER %I
                INTO %I;
            $f$, remote_schema, foreign_table, server_name, local_schema);
        END IF;
    END LOOP;
END;
$_$;


ALTER PROCEDURE public.sync_fdw_tables(IN local_schema text, IN remote_schema text, IN server_name text, IN metadata_schema text) OWNER TO dev_user;

--
-- Name: warehouse_server; Type: SERVER; Schema: -; Owner: dev_user
--

CREATE SERVER warehouse_server FOREIGN DATA WRAPPER postgres_fdw OPTIONS (
    dbname 'dwh',
    host 'localhost',
    port '5432'
);


ALTER SERVER warehouse_server OWNER TO dev_user;

--
-- Name: USER MAPPING dev_user SERVER warehouse_server; Type: USER MAPPING; Schema: -; Owner: dev_user
--

CREATE USER MAPPING FOR dev_user SERVER warehouse_server OPTIONS (
    password 'dev_password',
    "user" 'dev_user'
);


--
-- Name: billable_efforts_approveds; Type: FOREIGN TABLE; Schema: dwh_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE dwh_fdw.billable_efforts_approveds (
    effort_id text,
    user_id text,
    pod_id text,
    department_id text,
    effort double precision,
    month_year text,
    user_role text,
    status text,
    is_deleted text,
    created_time timestamp with time zone,
    updated_time timestamp with time zone,
    etl_datetime timestamp with time zone
)
SERVER warehouse_server
OPTIONS (
    schema_name 'public',
    table_name 'billable_efforts_approveds'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.billable_efforts_approveds ALTER COLUMN effort_id OPTIONS (
    column_name 'effort_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.billable_efforts_approveds ALTER COLUMN user_id OPTIONS (
    column_name 'user_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.billable_efforts_approveds ALTER COLUMN pod_id OPTIONS (
    column_name 'pod_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.billable_efforts_approveds ALTER COLUMN department_id OPTIONS (
    column_name 'department_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.billable_efforts_approveds ALTER COLUMN effort OPTIONS (
    column_name 'effort'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.billable_efforts_approveds ALTER COLUMN month_year OPTIONS (
    column_name 'month_year'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.billable_efforts_approveds ALTER COLUMN user_role OPTIONS (
    column_name 'user_role'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.billable_efforts_approveds ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.billable_efforts_approveds ALTER COLUMN is_deleted OPTIONS (
    column_name 'is_deleted'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.billable_efforts_approveds ALTER COLUMN created_time OPTIONS (
    column_name 'created_time'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.billable_efforts_approveds ALTER COLUMN updated_time OPTIONS (
    column_name 'updated_time'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.billable_efforts_approveds ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE dwh_fdw.billable_efforts_approveds OWNER TO dev_user;

--
-- Name: branches; Type: FOREIGN TABLE; Schema: dwh_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE dwh_fdw.branches (
    branch_id text,
    branch_code text,
    branch_name text,
    branch_address text,
    is_hidden text,
    status text,
    is_deleted text,
    created_time timestamp with time zone,
    etl_datetime timestamp with time zone
)
SERVER warehouse_server
OPTIONS (
    schema_name 'public',
    table_name 'branches'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.branches ALTER COLUMN branch_id OPTIONS (
    column_name 'branch_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.branches ALTER COLUMN branch_code OPTIONS (
    column_name 'branch_code'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.branches ALTER COLUMN branch_name OPTIONS (
    column_name 'branch_name'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.branches ALTER COLUMN branch_address OPTIONS (
    column_name 'branch_address'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.branches ALTER COLUMN is_hidden OPTIONS (
    column_name 'is_hidden'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.branches ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.branches ALTER COLUMN is_deleted OPTIONS (
    column_name 'is_deleted'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.branches ALTER COLUMN created_time OPTIONS (
    column_name 'created_time'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.branches ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE dwh_fdw.branches OWNER TO dev_user;

--
-- Name: departments; Type: FOREIGN TABLE; Schema: dwh_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE dwh_fdw.departments (
    department_id text,
    branch_id text,
    department_name text,
    level bigint,
    children text,
    parent_id text,
    status text,
    is_deleted text,
    updated_time timestamp with time zone,
    etl_datetime timestamp with time zone
)
SERVER warehouse_server
OPTIONS (
    schema_name 'public',
    table_name 'departments'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.departments ALTER COLUMN department_id OPTIONS (
    column_name 'department_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.departments ALTER COLUMN branch_id OPTIONS (
    column_name 'branch_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.departments ALTER COLUMN department_name OPTIONS (
    column_name 'department_name'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.departments ALTER COLUMN level OPTIONS (
    column_name 'level'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.departments ALTER COLUMN children OPTIONS (
    column_name 'children'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.departments ALTER COLUMN parent_id OPTIONS (
    column_name 'parent_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.departments ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.departments ALTER COLUMN is_deleted OPTIONS (
    column_name 'is_deleted'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.departments ALTER COLUMN updated_time OPTIONS (
    column_name 'updated_time'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.departments ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE dwh_fdw.departments OWNER TO dev_user;

--
-- Name: jira_issue_priority; Type: FOREIGN TABLE; Schema: dwh_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE dwh_fdw.jira_issue_priority (
    priority_id text,
    priority_name text,
    priority_description text,
    etl_datetime timestamp with time zone
)
SERVER warehouse_server
OPTIONS (
    schema_name 'public',
    table_name 'jira_issue_priority'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issue_priority ALTER COLUMN priority_id OPTIONS (
    column_name 'priority_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issue_priority ALTER COLUMN priority_name OPTIONS (
    column_name 'priority_name'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issue_priority ALTER COLUMN priority_description OPTIONS (
    column_name 'priority_description'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issue_priority ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE dwh_fdw.jira_issue_priority OWNER TO dev_user;

--
-- Name: jira_issue_resolution; Type: FOREIGN TABLE; Schema: dwh_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE dwh_fdw.jira_issue_resolution (
    resolution_id text,
    resolution_name text,
    resolution_description text,
    etl_datetime timestamp with time zone
)
SERVER warehouse_server
OPTIONS (
    schema_name 'public',
    table_name 'jira_issue_resolution'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issue_resolution ALTER COLUMN resolution_id OPTIONS (
    column_name 'resolution_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issue_resolution ALTER COLUMN resolution_name OPTIONS (
    column_name 'resolution_name'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issue_resolution ALTER COLUMN resolution_description OPTIONS (
    column_name 'resolution_description'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issue_resolution ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE dwh_fdw.jira_issue_resolution OWNER TO dev_user;

--
-- Name: jira_issue_status; Type: FOREIGN TABLE; Schema: dwh_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE dwh_fdw.jira_issue_status (
    status_id text,
    status_name text,
    status_description text,
    etl_datetime timestamp with time zone
)
SERVER warehouse_server
OPTIONS (
    schema_name 'public',
    table_name 'jira_issue_status'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issue_status ALTER COLUMN status_id OPTIONS (
    column_name 'status_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issue_status ALTER COLUMN status_name OPTIONS (
    column_name 'status_name'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issue_status ALTER COLUMN status_description OPTIONS (
    column_name 'status_description'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issue_status ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE dwh_fdw.jira_issue_status OWNER TO dev_user;

--
-- Name: jira_issue_types; Type: FOREIGN TABLE; Schema: dwh_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE dwh_fdw.jira_issue_types (
    type_id text,
    type_name text,
    type_description text,
    etl_datetime timestamp with time zone
)
SERVER warehouse_server
OPTIONS (
    schema_name 'public',
    table_name 'jira_issue_types'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issue_types ALTER COLUMN type_id OPTIONS (
    column_name 'type_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issue_types ALTER COLUMN type_name OPTIONS (
    column_name 'type_name'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issue_types ALTER COLUMN type_description OPTIONS (
    column_name 'type_description'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issue_types ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE dwh_fdw.jira_issue_types OWNER TO dev_user;

--
-- Name: jira_issues; Type: FOREIGN TABLE; Schema: dwh_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE dwh_fdw.jira_issues (
    issue_id double precision,
    issue_number double precision,
    jira_project_id double precision,
    issue_type text,
    issue_reporter text,
    issue_assignee text,
    issue_creator text,
    issue_summary text,
    issue_description text,
    issue_priority text,
    issue_resolution text,
    resolution_date timestamp without time zone,
    issue_status text,
    due_date timestamp without time zone,
    time_original_estimate double precision,
    time_estimate double precision,
    time_spent double precision,
    environment text,
    created_time timestamp without time zone,
    updated_time timestamp without time zone,
    etl_datetime timestamp with time zone
)
SERVER warehouse_server
OPTIONS (
    schema_name 'public',
    table_name 'jira_issues'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issues ALTER COLUMN issue_id OPTIONS (
    column_name 'issue_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issues ALTER COLUMN issue_number OPTIONS (
    column_name 'issue_number'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issues ALTER COLUMN jira_project_id OPTIONS (
    column_name 'jira_project_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issues ALTER COLUMN issue_type OPTIONS (
    column_name 'issue_type'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issues ALTER COLUMN issue_reporter OPTIONS (
    column_name 'issue_reporter'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issues ALTER COLUMN issue_assignee OPTIONS (
    column_name 'issue_assignee'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issues ALTER COLUMN issue_creator OPTIONS (
    column_name 'issue_creator'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issues ALTER COLUMN issue_summary OPTIONS (
    column_name 'issue_summary'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issues ALTER COLUMN issue_description OPTIONS (
    column_name 'issue_description'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issues ALTER COLUMN issue_priority OPTIONS (
    column_name 'issue_priority'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issues ALTER COLUMN issue_resolution OPTIONS (
    column_name 'issue_resolution'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issues ALTER COLUMN resolution_date OPTIONS (
    column_name 'resolution_date'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issues ALTER COLUMN issue_status OPTIONS (
    column_name 'issue_status'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issues ALTER COLUMN due_date OPTIONS (
    column_name 'due_date'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issues ALTER COLUMN time_original_estimate OPTIONS (
    column_name 'time_original_estimate'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issues ALTER COLUMN time_estimate OPTIONS (
    column_name 'time_estimate'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issues ALTER COLUMN time_spent OPTIONS (
    column_name 'time_spent'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issues ALTER COLUMN environment OPTIONS (
    column_name 'environment'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issues ALTER COLUMN created_time OPTIONS (
    column_name 'created_time'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issues ALTER COLUMN updated_time OPTIONS (
    column_name 'updated_time'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_issues ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE dwh_fdw.jira_issues OWNER TO dev_user;

--
-- Name: jira_worklog; Type: FOREIGN TABLE; Schema: dwh_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE dwh_fdw.jira_worklog (
    worklog_id double precision,
    issue_id double precision,
    worklog_author text,
    worklog_description text,
    start_time timestamp without time zone,
    time_worked double precision,
    update_author text,
    created_time timestamp without time zone,
    updated_time timestamp without time zone,
    etl_datetime timestamp with time zone
)
SERVER warehouse_server
OPTIONS (
    schema_name 'public',
    table_name 'jira_worklog'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_worklog ALTER COLUMN worklog_id OPTIONS (
    column_name 'worklog_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_worklog ALTER COLUMN issue_id OPTIONS (
    column_name 'issue_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_worklog ALTER COLUMN worklog_author OPTIONS (
    column_name 'worklog_author'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_worklog ALTER COLUMN worklog_description OPTIONS (
    column_name 'worklog_description'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_worklog ALTER COLUMN start_time OPTIONS (
    column_name 'start_time'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_worklog ALTER COLUMN time_worked OPTIONS (
    column_name 'time_worked'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_worklog ALTER COLUMN update_author OPTIONS (
    column_name 'update_author'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_worklog ALTER COLUMN created_time OPTIONS (
    column_name 'created_time'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_worklog ALTER COLUMN updated_time OPTIONS (
    column_name 'updated_time'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.jira_worklog ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE dwh_fdw.jira_worklog OWNER TO dev_user;

--
-- Name: pods; Type: FOREIGN TABLE; Schema: dwh_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE dwh_fdw.pods (
    pod_id text,
    project_code text,
    project_name text,
    project_type text,
    project_size text,
    project_rank text,
    project_overview text,
    project_category text,
    warranty_condition text,
    development_model text,
    department_id text,
    jira_url text,
    start_date timestamp with time zone,
    plan_uat_date timestamp with time zone,
    plan_release_date timestamp with time zone,
    final_release_date timestamp with time zone,
    pod_status text,
    status text,
    is_deleted text,
    created_time timestamp with time zone,
    updated_time timestamp with time zone,
    etl_datetime timestamp with time zone
)
SERVER warehouse_server
OPTIONS (
    schema_name 'public',
    table_name 'pods'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.pods ALTER COLUMN pod_id OPTIONS (
    column_name 'pod_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.pods ALTER COLUMN project_code OPTIONS (
    column_name 'project_code'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.pods ALTER COLUMN project_name OPTIONS (
    column_name 'project_name'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.pods ALTER COLUMN project_type OPTIONS (
    column_name 'project_type'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.pods ALTER COLUMN project_size OPTIONS (
    column_name 'project_size'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.pods ALTER COLUMN project_rank OPTIONS (
    column_name 'project_rank'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.pods ALTER COLUMN project_overview OPTIONS (
    column_name 'project_overview'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.pods ALTER COLUMN project_category OPTIONS (
    column_name 'project_category'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.pods ALTER COLUMN warranty_condition OPTIONS (
    column_name 'warranty_condition'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.pods ALTER COLUMN development_model OPTIONS (
    column_name 'development_model'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.pods ALTER COLUMN department_id OPTIONS (
    column_name 'department_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.pods ALTER COLUMN jira_url OPTIONS (
    column_name 'jira_url'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.pods ALTER COLUMN start_date OPTIONS (
    column_name 'start_date'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.pods ALTER COLUMN plan_uat_date OPTIONS (
    column_name 'plan_uat_date'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.pods ALTER COLUMN plan_release_date OPTIONS (
    column_name 'plan_release_date'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.pods ALTER COLUMN final_release_date OPTIONS (
    column_name 'final_release_date'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.pods ALTER COLUMN pod_status OPTIONS (
    column_name 'pod_status'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.pods ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.pods ALTER COLUMN is_deleted OPTIONS (
    column_name 'is_deleted'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.pods ALTER COLUMN created_time OPTIONS (
    column_name 'created_time'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.pods ALTER COLUMN updated_time OPTIONS (
    column_name 'updated_time'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.pods ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE dwh_fdw.pods OWNER TO dev_user;

--
-- Name: project_members; Type: FOREIGN TABLE; Schema: dwh_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE dwh_fdw.project_members (
    project_id text,
    user_id text,
    joined_at timestamp with time zone,
    left_at timestamp with time zone,
    status text,
    is_deleted text,
    user_level double precision,
    updated_time timestamp with time zone,
    etl_datetime timestamp with time zone
)
SERVER warehouse_server
OPTIONS (
    schema_name 'public',
    table_name 'project_members'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.project_members ALTER COLUMN project_id OPTIONS (
    column_name 'project_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.project_members ALTER COLUMN user_id OPTIONS (
    column_name 'user_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.project_members ALTER COLUMN joined_at OPTIONS (
    column_name 'joined_at'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.project_members ALTER COLUMN left_at OPTIONS (
    column_name 'left_at'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.project_members ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.project_members ALTER COLUMN is_deleted OPTIONS (
    column_name 'is_deleted'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.project_members ALTER COLUMN user_level OPTIONS (
    column_name 'user_level'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.project_members ALTER COLUMN updated_time OPTIONS (
    column_name 'updated_time'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.project_members ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE dwh_fdw.project_members OWNER TO dev_user;

--
-- Name: project_profit_loss; Type: FOREIGN TABLE; Schema: dwh_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE dwh_fdw.project_profit_loss (
    project_id text,
    user_id text,
    department_id text,
    branch_id text,
    value double precision,
    value1 bigint,
    status text,
    is_deleted text,
    month_at text,
    updated_time timestamp with time zone,
    etl_datetime timestamp with time zone
)
SERVER warehouse_server
OPTIONS (
    schema_name 'public',
    table_name 'project_profit_loss'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.project_profit_loss ALTER COLUMN project_id OPTIONS (
    column_name 'project_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.project_profit_loss ALTER COLUMN user_id OPTIONS (
    column_name 'user_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.project_profit_loss ALTER COLUMN department_id OPTIONS (
    column_name 'department_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.project_profit_loss ALTER COLUMN branch_id OPTIONS (
    column_name 'branch_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.project_profit_loss ALTER COLUMN value OPTIONS (
    column_name 'value'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.project_profit_loss ALTER COLUMN value1 OPTIONS (
    column_name 'value1'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.project_profit_loss ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.project_profit_loss ALTER COLUMN is_deleted OPTIONS (
    column_name 'is_deleted'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.project_profit_loss ALTER COLUMN month_at OPTIONS (
    column_name 'month_at'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.project_profit_loss ALTER COLUMN updated_time OPTIONS (
    column_name 'updated_time'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.project_profit_loss ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE dwh_fdw.project_profit_loss OWNER TO dev_user;

--
-- Name: projects; Type: FOREIGN TABLE; Schema: dwh_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE dwh_fdw.projects (
    project_id text,
    jira_project_id double precision,
    project_name text,
    project_jira_url text,
    project_description text,
    project_lead text,
    project_code text,
    project_status text,
    project_type text,
    is_deleted text,
    name_pm text,
    name_brse text,
    location text,
    scope text,
    type text,
    point_css double precision,
    point_comment text,
    summary text,
    size double precision,
    period double precision,
    project_rank bigint,
    team_size text,
    start_date timestamp without time zone,
    end_date timestamp without time zone,
    updated_time timestamp without time zone,
    etl_datetime timestamp with time zone
)
SERVER warehouse_server
OPTIONS (
    schema_name 'public',
    table_name 'projects'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.projects ALTER COLUMN project_id OPTIONS (
    column_name 'project_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.projects ALTER COLUMN jira_project_id OPTIONS (
    column_name 'jira_project_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.projects ALTER COLUMN project_name OPTIONS (
    column_name 'project_name'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.projects ALTER COLUMN project_jira_url OPTIONS (
    column_name 'project_jira_url'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.projects ALTER COLUMN project_description OPTIONS (
    column_name 'project_description'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.projects ALTER COLUMN project_lead OPTIONS (
    column_name 'project_lead'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.projects ALTER COLUMN project_code OPTIONS (
    column_name 'project_code'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.projects ALTER COLUMN project_status OPTIONS (
    column_name 'project_status'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.projects ALTER COLUMN project_type OPTIONS (
    column_name 'project_type'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.projects ALTER COLUMN is_deleted OPTIONS (
    column_name 'is_deleted'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.projects ALTER COLUMN name_pm OPTIONS (
    column_name 'name_pm'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.projects ALTER COLUMN name_brse OPTIONS (
    column_name 'name_brse'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.projects ALTER COLUMN location OPTIONS (
    column_name 'location'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.projects ALTER COLUMN scope OPTIONS (
    column_name 'scope'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.projects ALTER COLUMN type OPTIONS (
    column_name 'type'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.projects ALTER COLUMN point_css OPTIONS (
    column_name 'point_css'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.projects ALTER COLUMN point_comment OPTIONS (
    column_name 'point_comment'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.projects ALTER COLUMN summary OPTIONS (
    column_name 'summary'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.projects ALTER COLUMN size OPTIONS (
    column_name 'size'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.projects ALTER COLUMN period OPTIONS (
    column_name 'period'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.projects ALTER COLUMN project_rank OPTIONS (
    column_name 'project_rank'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.projects ALTER COLUMN team_size OPTIONS (
    column_name 'team_size'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.projects ALTER COLUMN start_date OPTIONS (
    column_name 'start_date'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.projects ALTER COLUMN end_date OPTIONS (
    column_name 'end_date'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.projects ALTER COLUMN updated_time OPTIONS (
    column_name 'updated_time'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.projects ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE dwh_fdw.projects OWNER TO dev_user;

--
-- Name: salaries; Type: FOREIGN TABLE; Schema: dwh_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE dwh_fdw.salaries (
    salary_id text,
    user_id text,
    insurance text,
    basic_salary text,
    total_salary text,
    is_deleted text,
    status text,
    user_info_block text,
    created_time timestamp with time zone,
    updated_time timestamp with time zone,
    etl_datetime timestamp with time zone
)
SERVER warehouse_server
OPTIONS (
    schema_name 'public',
    table_name 'salaries'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.salaries ALTER COLUMN salary_id OPTIONS (
    column_name 'salary_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.salaries ALTER COLUMN user_id OPTIONS (
    column_name 'user_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.salaries ALTER COLUMN insurance OPTIONS (
    column_name 'insurance'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.salaries ALTER COLUMN basic_salary OPTIONS (
    column_name 'basic_salary'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.salaries ALTER COLUMN total_salary OPTIONS (
    column_name 'total_salary'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.salaries ALTER COLUMN is_deleted OPTIONS (
    column_name 'is_deleted'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.salaries ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.salaries ALTER COLUMN user_info_block OPTIONS (
    column_name 'user_info_block'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.salaries ALTER COLUMN created_time OPTIONS (
    column_name 'created_time'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.salaries ALTER COLUMN updated_time OPTIONS (
    column_name 'updated_time'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.salaries ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE dwh_fdw.salaries OWNER TO dev_user;

--
-- Name: staff_attendances; Type: FOREIGN TABLE; Schema: dwh_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE dwh_fdw.staff_attendances (
    attendance_id text,
    user_id text,
    attendance_type_id text,
    from_date timestamp with time zone,
    end_date timestamp with time zone,
    absent_day double precision,
    absent_reason text,
    status_approval text,
    date_approval timestamp with time zone,
    type text,
    status text,
    is_deleted text,
    created_time timestamp with time zone,
    updated_time timestamp with time zone,
    etl_datetime timestamp with time zone
)
SERVER warehouse_server
OPTIONS (
    schema_name 'public',
    table_name 'staff_attendances'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances ALTER COLUMN attendance_id OPTIONS (
    column_name 'attendance_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances ALTER COLUMN user_id OPTIONS (
    column_name 'user_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances ALTER COLUMN attendance_type_id OPTIONS (
    column_name 'attendance_type_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances ALTER COLUMN from_date OPTIONS (
    column_name 'from_date'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances ALTER COLUMN end_date OPTIONS (
    column_name 'end_date'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances ALTER COLUMN absent_day OPTIONS (
    column_name 'absent_day'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances ALTER COLUMN absent_reason OPTIONS (
    column_name 'absent_reason'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances ALTER COLUMN status_approval OPTIONS (
    column_name 'status_approval'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances ALTER COLUMN date_approval OPTIONS (
    column_name 'date_approval'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances ALTER COLUMN type OPTIONS (
    column_name 'type'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances ALTER COLUMN is_deleted OPTIONS (
    column_name 'is_deleted'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances ALTER COLUMN created_time OPTIONS (
    column_name 'created_time'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances ALTER COLUMN updated_time OPTIONS (
    column_name 'updated_time'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE dwh_fdw.staff_attendances OWNER TO dev_user;

--
-- Name: staff_attendances_types; Type: FOREIGN TABLE; Schema: dwh_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE dwh_fdw.staff_attendances_types (
    attendance_type_id text,
    attendance_type_name text,
    attendance_type_code text,
    attendance_work_day bigint,
    status text,
    is_deleted text,
    type text,
    unit_status text,
    unit_type text,
    unit_value double precision,
    created_time timestamp with time zone,
    updated_time timestamp with time zone,
    etl_datetime timestamp with time zone
)
SERVER warehouse_server
OPTIONS (
    schema_name 'public',
    table_name 'staff_attendances_types'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances_types ALTER COLUMN attendance_type_id OPTIONS (
    column_name 'attendance_type_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances_types ALTER COLUMN attendance_type_name OPTIONS (
    column_name 'attendance_type_name'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances_types ALTER COLUMN attendance_type_code OPTIONS (
    column_name 'attendance_type_code'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances_types ALTER COLUMN attendance_work_day OPTIONS (
    column_name 'attendance_work_day'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances_types ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances_types ALTER COLUMN is_deleted OPTIONS (
    column_name 'is_deleted'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances_types ALTER COLUMN type OPTIONS (
    column_name 'type'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances_types ALTER COLUMN unit_status OPTIONS (
    column_name 'unit_status'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances_types ALTER COLUMN unit_type OPTIONS (
    column_name 'unit_type'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances_types ALTER COLUMN unit_value OPTIONS (
    column_name 'unit_value'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances_types ALTER COLUMN created_time OPTIONS (
    column_name 'created_time'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances_types ALTER COLUMN updated_time OPTIONS (
    column_name 'updated_time'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.staff_attendances_types ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE dwh_fdw.staff_attendances_types OWNER TO dev_user;

--
-- Name: time_series; Type: FOREIGN TABLE; Schema: dwh_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE dwh_fdw.time_series (
    time_id integer NOT NULL,
    date date NOT NULL,
    year integer,
    month integer,
    month_name character varying(10),
    quarter integer,
    is_month_end boolean
)
SERVER warehouse_server
OPTIONS (
    schema_name 'public',
    table_name 'time_series'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.time_series ALTER COLUMN time_id OPTIONS (
    column_name 'time_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.time_series ALTER COLUMN date OPTIONS (
    column_name 'date'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.time_series ALTER COLUMN year OPTIONS (
    column_name 'year'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.time_series ALTER COLUMN month OPTIONS (
    column_name 'month'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.time_series ALTER COLUMN month_name OPTIONS (
    column_name 'month_name'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.time_series ALTER COLUMN quarter OPTIONS (
    column_name 'quarter'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.time_series ALTER COLUMN is_month_end OPTIONS (
    column_name 'is_month_end'
);


ALTER FOREIGN TABLE dwh_fdw.time_series OWNER TO dev_user;

--
-- Name: user_positions; Type: FOREIGN TABLE; Schema: dwh_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE dwh_fdw.user_positions (
    position_id text,
    position_code text,
    position_name text,
    position_level double precision,
    position_description text,
    position_status text,
    position_type text,
    status text,
    is_deleted text,
    updated_time text,
    etl_datetime timestamp with time zone
)
SERVER warehouse_server
OPTIONS (
    schema_name 'public',
    table_name 'user_positions'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.user_positions ALTER COLUMN position_id OPTIONS (
    column_name 'position_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.user_positions ALTER COLUMN position_code OPTIONS (
    column_name 'position_code'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.user_positions ALTER COLUMN position_name OPTIONS (
    column_name 'position_name'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.user_positions ALTER COLUMN position_level OPTIONS (
    column_name 'position_level'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.user_positions ALTER COLUMN position_description OPTIONS (
    column_name 'position_description'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.user_positions ALTER COLUMN position_status OPTIONS (
    column_name 'position_status'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.user_positions ALTER COLUMN position_type OPTIONS (
    column_name 'position_type'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.user_positions ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.user_positions ALTER COLUMN is_deleted OPTIONS (
    column_name 'is_deleted'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.user_positions ALTER COLUMN updated_time OPTIONS (
    column_name 'updated_time'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.user_positions ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE dwh_fdw.user_positions OWNER TO dev_user;

--
-- Name: users; Type: FOREIGN TABLE; Schema: dwh_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE dwh_fdw.users (
    user_id text,
    user_name text,
    birthday date,
    address text,
    gender text,
    personal_email text,
    mobile text,
    username text,
    password text,
    company_email text,
    staff_code double precision,
    branch_id text,
    department_id text,
    position_id text,
    welcome_day date,
    probation_date date,
    quit_date date,
    user_level text,
    user_status text,
    is_deleted text,
    etl_datetime timestamp with time zone
)
SERVER warehouse_server
OPTIONS (
    schema_name 'public',
    table_name 'users'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.users ALTER COLUMN user_id OPTIONS (
    column_name 'user_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.users ALTER COLUMN user_name OPTIONS (
    column_name 'user_name'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.users ALTER COLUMN birthday OPTIONS (
    column_name 'birthday'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.users ALTER COLUMN address OPTIONS (
    column_name 'address'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.users ALTER COLUMN gender OPTIONS (
    column_name 'gender'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.users ALTER COLUMN personal_email OPTIONS (
    column_name 'personal_email'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.users ALTER COLUMN mobile OPTIONS (
    column_name 'mobile'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.users ALTER COLUMN username OPTIONS (
    column_name 'username'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.users ALTER COLUMN password OPTIONS (
    column_name 'password'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.users ALTER COLUMN company_email OPTIONS (
    column_name 'company_email'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.users ALTER COLUMN staff_code OPTIONS (
    column_name 'staff_code'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.users ALTER COLUMN branch_id OPTIONS (
    column_name 'branch_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.users ALTER COLUMN department_id OPTIONS (
    column_name 'department_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.users ALTER COLUMN position_id OPTIONS (
    column_name 'position_id'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.users ALTER COLUMN welcome_day OPTIONS (
    column_name 'welcome_day'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.users ALTER COLUMN probation_date OPTIONS (
    column_name 'probation_date'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.users ALTER COLUMN quit_date OPTIONS (
    column_name 'quit_date'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.users ALTER COLUMN user_level OPTIONS (
    column_name 'user_level'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.users ALTER COLUMN user_status OPTIONS (
    column_name 'user_status'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.users ALTER COLUMN is_deleted OPTIONS (
    column_name 'is_deleted'
);
ALTER FOREIGN TABLE ONLY dwh_fdw.users ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE dwh_fdw.users OWNER TO dev_user;

--
-- Name: tables; Type: FOREIGN TABLE; Schema: fdw_metadata; Owner: dev_user
--

CREATE FOREIGN TABLE fdw_metadata.tables (
    table_catalog information_schema.sql_identifier,
    table_schema information_schema.sql_identifier,
    table_name information_schema.sql_identifier,
    table_type information_schema.character_data,
    self_referencing_column_name information_schema.sql_identifier,
    reference_generation information_schema.character_data,
    user_defined_type_catalog information_schema.sql_identifier,
    user_defined_type_schema information_schema.sql_identifier,
    user_defined_type_name information_schema.sql_identifier,
    is_insertable_into information_schema.yes_or_no,
    is_typed information_schema.yes_or_no,
    commit_action information_schema.character_data
)
SERVER warehouse_server
OPTIONS (
    schema_name 'information_schema',
    table_name 'tables'
);
ALTER FOREIGN TABLE ONLY fdw_metadata.tables ALTER COLUMN table_catalog OPTIONS (
    column_name 'table_catalog'
);
ALTER FOREIGN TABLE ONLY fdw_metadata.tables ALTER COLUMN table_schema OPTIONS (
    column_name 'table_schema'
);
ALTER FOREIGN TABLE ONLY fdw_metadata.tables ALTER COLUMN table_name OPTIONS (
    column_name 'table_name'
);
ALTER FOREIGN TABLE ONLY fdw_metadata.tables ALTER COLUMN table_type OPTIONS (
    column_name 'table_type'
);
ALTER FOREIGN TABLE ONLY fdw_metadata.tables ALTER COLUMN self_referencing_column_name OPTIONS (
    column_name 'self_referencing_column_name'
);
ALTER FOREIGN TABLE ONLY fdw_metadata.tables ALTER COLUMN reference_generation OPTIONS (
    column_name 'reference_generation'
);
ALTER FOREIGN TABLE ONLY fdw_metadata.tables ALTER COLUMN user_defined_type_catalog OPTIONS (
    column_name 'user_defined_type_catalog'
);
ALTER FOREIGN TABLE ONLY fdw_metadata.tables ALTER COLUMN user_defined_type_schema OPTIONS (
    column_name 'user_defined_type_schema'
);
ALTER FOREIGN TABLE ONLY fdw_metadata.tables ALTER COLUMN user_defined_type_name OPTIONS (
    column_name 'user_defined_type_name'
);
ALTER FOREIGN TABLE ONLY fdw_metadata.tables ALTER COLUMN is_insertable_into OPTIONS (
    column_name 'is_insertable_into'
);
ALTER FOREIGN TABLE ONLY fdw_metadata.tables ALTER COLUMN is_typed OPTIONS (
    column_name 'is_typed'
);
ALTER FOREIGN TABLE ONLY fdw_metadata.tables ALTER COLUMN commit_action OPTIONS (
    column_name 'commit_action'
);


ALTER FOREIGN TABLE fdw_metadata.tables OWNER TO dev_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dim_branches; Type: TABLE; Schema: hr; Owner: dev_user
--

CREATE TABLE hr.dim_branches (
    branch_id text,
    branch_name text
);


ALTER TABLE hr.dim_branches OWNER TO dev_user;

--
-- Name: dim_departments; Type: TABLE; Schema: hr; Owner: dev_user
--

CREATE TABLE hr.dim_departments (
    department_id text,
    department_name text
);


ALTER TABLE hr.dim_departments OWNER TO dev_user;

--
-- Name: dim_month_year; Type: TABLE; Schema: hr; Owner: dev_user
--

CREATE TABLE hr.dim_month_year (
    date date,
    freq_code text,
    year text,
    month_name character varying(10),
    month_year text
);


ALTER TABLE hr.dim_month_year OWNER TO dev_user;

--
-- Name: dim_positions; Type: TABLE; Schema: hr; Owner: dev_user
--

CREATE TABLE hr.dim_positions (
    position_id text,
    position_name text
);


ALTER TABLE hr.dim_positions OWNER TO dev_user;

--
-- Name: fct_hrm_employees; Type: TABLE; Schema: hr; Owner: dev_user
--

CREATE TABLE hr.fct_hrm_employees (
    report_date date,
    emp_id text,
    emp_name text,
    emp_dob date,
    emp_age numeric,
    emp_gender text,
    emp_email text,
    staff_code double precision,
    branch_id text,
    department_id text,
    position_id text,
    emp_level text,
    emp_status text,
    probation_date date,
    quit_date date,
    tenure_years numeric,
    total_absence double precision,
    emp_salary integer,
    satisfaction_score integer,
    engagement_score numeric,
    performance_score text
);


ALTER TABLE hr.fct_hrm_employees OWNER TO dev_user;

--
-- Name: dim_members; Type: TABLE; Schema: jira; Owner: dev_user
--

CREATE TABLE jira.dim_members (
    member_id text,
    member_name text,
    member_email text,
    staff_code double precision,
    branch_name text,
    department_name text,
    position_name text,
    user_level text,
    user_status text
);


ALTER TABLE jira.dim_members OWNER TO dev_user;

--
-- Name: dim_pods; Type: TABLE; Schema: jira; Owner: dev_user
--

CREATE TABLE jira.dim_pods (
    pod_id text,
    project_code text,
    project_name text,
    project_size text,
    jira_url text,
    department_id text,
    start_date timestamp with time zone,
    plan_uat_date timestamp with time zone,
    plan_release_date timestamp with time zone,
    final_release_date timestamp with time zone,
    pod_status text,
    status text
);


ALTER TABLE jira.dim_pods OWNER TO dev_user;

--
-- Name: dim_projects; Type: TABLE; Schema: jira; Owner: dev_user
--

CREATE TABLE jira.dim_projects (
    project_id text,
    jira_project_id double precision,
    project_name text,
    project_jira_url text,
    project_lead text,
    project_status text,
    location text,
    scope text,
    type text,
    point_css double precision,
    summary text,
    size double precision,
    period double precision,
    team_size text,
    start_date timestamp without time zone,
    end_date timestamp without time zone,
    project_value double precision
);


ALTER TABLE jira.dim_projects OWNER TO dev_user;

--
-- Name: dim_time_series; Type: TABLE; Schema: jira; Owner: dev_user
--

CREATE TABLE jira.dim_time_series (
    date date,
    week_year text,
    year integer,
    month_name character varying(10),
    month_year text,
    is_month_end boolean
);


ALTER TABLE jira.dim_time_series OWNER TO dev_user;

--
-- Name: fct_issues; Type: TABLE; Schema: jira; Owner: dev_user
--

CREATE TABLE jira.fct_issues (
    issue_id double precision,
    jira_project_id double precision,
    issue_assignee text,
    priority text,
    type text,
    resolution text,
    resolution_date timestamp without time zone,
    status text,
    due_date timestamp without time zone,
    time_original_estimate double precision,
    time_estimate double precision,
    time_spent double precision,
    created_time timestamp without time zone,
    updated_time timestamp without time zone
);


ALTER TABLE jira.fct_issues OWNER TO dev_user;

--
-- Name: fct_pod_member_efforts; Type: TABLE; Schema: jira; Owner: dev_user
--

CREATE TABLE jira.fct_pod_member_efforts (
    pod_id text,
    user_id text,
    department_id text,
    user_role text,
    effort double precision,
    month_year text,
    status text
);


ALTER TABLE jira.fct_pod_member_efforts OWNER TO dev_user;

--
-- Name: fct_project_members; Type: TABLE; Schema: jira; Owner: dev_user
--

CREATE TABLE jira.fct_project_members (
    project_id text,
    user_id text,
    joined_at timestamp with time zone,
    left_at timestamp with time zone
);


ALTER TABLE jira.fct_project_members OWNER TO dev_user;

--
-- Name: fct_worklog; Type: TABLE; Schema: jira; Owner: dev_user
--

CREATE TABLE jira.fct_worklog (
    worklog_id double precision,
    issue_id double precision,
    jira_project_id double precision,
    worklog_author text,
    worklog_description text,
    start_time timestamp without time zone,
    time_worked double precision,
    created_time timestamp without time zone,
    updated_time timestamp without time zone
);


ALTER TABLE jira.fct_worklog OWNER TO dev_user;

--
-- Name: mview_member_free_effort; Type: MATERIALIZED VIEW; Schema: jira; Owner: dev_user
--

CREATE MATERIALIZED VIEW jira.mview_member_free_effort AS
 WITH _time_series AS (
         SELECT to_char((generate_series((date_trunc('month'::text, (date_trunc('year'::text, (CURRENT_DATE)::timestamp with time zone) - '5 years'::interval)) + '11 mons'::interval), (date_trunc('month'::text, date_trunc('year'::text, (CURRENT_DATE)::timestamp with time zone)) + '11 mons'::interval), '1 mon'::interval) + '1 mon -1 days'::interval), 'YYYY-MM'::text) AS month_year
        ), _jira_efforts AS (
         SELECT dim_members.member_email,
            to_char(w.start_time, 'YYYY-MM'::text) AS month_year,
            ((sum(w.time_worked) / (3600)::double precision) / (160)::double precision) AS actual_efforts,
            avg(((sum(w.time_worked) / (3600)::double precision) / (160)::double precision)) OVER (ORDER BY (to_char(w.start_time, 'YYYY-MM'::text)) ROWS BETWEEN 3 PRECEDING AND CURRENT ROW) AS ma4,
            count(DISTINCT dim_members.member_id) AS normal_efforts
           FROM (jira.fct_worklog w
             JOIN jira.dim_members ON ((dim_members.member_email = w.worklog_author)))
          GROUP BY dim_members.member_email, (to_char(w.start_time, 'YYYY-MM'::text))
        ), _pod_efforts AS (
         SELECT dim_members.member_email,
            pme.month_year,
            sum(pme.effort) AS pod_efforts,
            count(DISTINCT dim_members.member_id) AS normal_efforts
           FROM (jira.fct_pod_member_efforts pme
             JOIN jira.dim_members ON ((dim_members.member_id = pme.user_id)))
          GROUP BY dim_members.member_email, pme.month_year
        ), _efforts AS (
         SELECT COALESCE(je.member_email, pe.member_email) AS member_email,
            COALESCE(je.month_year, pe.month_year, ts.month_year) AS month_year,
            COALESCE(je.normal_efforts, pe.normal_efforts) AS normal_efforts,
            je.actual_efforts,
            je.ma4,
            pe.pod_efforts
           FROM ((_time_series ts
             FULL JOIN _pod_efforts pe ON ((pe.month_year = ts.month_year)))
             FULL JOIN _jira_efforts je ON (((je.month_year = ts.month_year) AND (je.member_email = pe.member_email))))
        ), _predicting_efforts AS (
         SELECT _efforts.member_email,
            _efforts.month_year,
            _efforts.actual_efforts,
            lag(_efforts.ma4) OVER (PARTITION BY _efforts.member_email ORDER BY _efforts.month_year) AS predicting_efforts,
            _efforts.pod_efforts,
            _efforts.normal_efforts
           FROM _efforts
        ), _final AS (
         SELECT t.member_email,
            t.month_year,
            t.actual_efforts,
            first_value(t.predicting_efforts) OVER (PARTITION BY t.x, t.member_email ORDER BY t.month_year, t.x NULLS FIRST) AS predicting_efforts,
            t.pod_efforts,
            t.normal_efforts
           FROM ( SELECT _predicting_efforts.member_email,
                    _predicting_efforts.month_year,
                    _predicting_efforts.actual_efforts,
                    _predicting_efforts.predicting_efforts,
                    _predicting_efforts.pod_efforts,
                    _predicting_efforts.normal_efforts,
                    sum(
                        CASE
                            WHEN (_predicting_efforts.predicting_efforts IS NOT NULL) THEN 1
                            ELSE NULL::integer
                        END) OVER (PARTITION BY _predicting_efforts.member_email ORDER BY _predicting_efforts.month_year) AS x
                   FROM _predicting_efforts) t
        )
 SELECT _final.member_email,
    _final.month_year,
    _final.actual_efforts,
    _final.predicting_efforts,
    _final.pod_efforts,
    _final.normal_efforts,
    ((_final.normal_efforts)::double precision - COALESCE(_final.actual_efforts, _final.pod_efforts, _final.predicting_efforts)) AS free_efforts
   FROM _final
  WHERE (_final.member_email IS NOT NULL)
  WITH NO DATA;


ALTER MATERIALIZED VIEW jira.mview_member_free_effort OWNER TO dev_user;

--
-- Name: m2fe_unique_idx; Type: INDEX; Schema: jira; Owner: dev_user
--

CREATE UNIQUE INDEX m2fe_unique_idx ON jira.mview_member_free_effort USING btree (member_email, month_year);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: dev_user
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

--
-- Database "dwh" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 14.18
-- Dumped by pg_dump version 17.5 (Debian 17.5-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: dwh; Type: DATABASE; Schema: -; Owner: dev_user
--

CREATE DATABASE dwh WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE dwh OWNER TO dev_user;

\connect dwh

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: create_fdw; Type: SCHEMA; Schema: -; Owner: dev_user
--

CREATE SCHEMA create_fdw;


ALTER SCHEMA create_fdw OWNER TO dev_user;

--
-- Name: fdw_metadata; Type: SCHEMA; Schema: -; Owner: dev_user
--

CREATE SCHEMA fdw_metadata;


ALTER SCHEMA fdw_metadata OWNER TO dev_user;

--
-- Name: jira_fdw; Type: SCHEMA; Schema: -; Owner: dev_user
--

CREATE SCHEMA jira_fdw;


ALTER SCHEMA jira_fdw OWNER TO dev_user;

--
-- Name: jisseki_fdw; Type: SCHEMA; Schema: -; Owner: dev_user
--

CREATE SCHEMA jisseki_fdw;


ALTER SCHEMA jisseki_fdw OWNER TO dev_user;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: dev_user
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO dev_user;

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: postgres_fdw; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgres_fdw WITH SCHEMA public;


--
-- Name: EXTENSION postgres_fdw; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgres_fdw IS 'foreign-data wrapper for remote PostgreSQL servers';


--
-- Name: sync_fdw_tables(text, text, text, text); Type: PROCEDURE; Schema: public; Owner: dev_user
--

CREATE PROCEDURE public.sync_fdw_tables(IN local_schema text, IN remote_schema text, IN server_name text, IN metadata_schema text DEFAULT 'fdw_metadata'::text)
    LANGUAGE plpgsql
    AS $_$
DECLARE
    foreign_table TEXT;
    existing_tables TEXT[];
BEGIN

    SELECT array_agg(ft.relname)
    INTO existing_tables
    FROM pg_foreign_table f
    JOIN pg_class ft ON f.ftrelid = ft.oid
    JOIN pg_namespace ns ON ft.relnamespace = ns.oid
    WHERE ns.nspname = local_schema;

    FOR foreign_table IN
        EXECUTE format(
            'SELECT table_name FROM %I.tables WHERE table_schema = %L AND table_type = %L',
            metadata_schema, remote_schema, 'BASE TABLE'
        )
    LOOP
        IF existing_tables IS NULL OR NOT foreign_table = ANY(existing_tables) THEN
            RAISE NOTICE 'Importing new table: %', foreign_table;

            EXECUTE format($f$
                IMPORT FOREIGN SCHEMA %I
                LIMIT TO (%I)
                FROM SERVER %I
                INTO %I;
            $f$, remote_schema, foreign_table, server_name, local_schema);
        END IF;
    END LOOP;
END;
$_$;


ALTER PROCEDURE public.sync_fdw_tables(IN local_schema text, IN remote_schema text, IN server_name text, IN metadata_schema text) OWNER TO dev_user;

--
-- Name: staging_server; Type: SERVER; Schema: -; Owner: dev_user
--

CREATE SERVER staging_server FOREIGN DATA WRAPPER postgres_fdw OPTIONS (
    dbname 'stg',
    host 'localhost',
    port '5432'
);


ALTER SERVER staging_server OWNER TO dev_user;

--
-- Name: USER MAPPING dev_user SERVER staging_server; Type: USER MAPPING; Schema: -; Owner: dev_user
--

CREATE USER MAPPING FOR dev_user SERVER staging_server OPTIONS (
    password 'dev_password',
    "user" 'dev_user'
);


--
-- Name: stg_billable_efforts_approveds; Type: FOREIGN TABLE; Schema: create_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE create_fdw.stg_billable_efforts_approveds (
    _id text,
    "employeeObjId" text,
    month text,
    "pODObjId" text,
    "rowKey" text,
    year text,
    "createdAt" text,
    "createdBy" text,
    "departmentObjId" text,
    effort double precision,
    "isDeleted" text,
    note text,
    role text,
    status text,
    "updatedAt" text,
    "updatedBy" text,
    "departmentVendor" text,
    "isVendor" boolean,
    type text,
    username text,
    etl_datetime timestamp without time zone
)
SERVER staging_server
OPTIONS (
    schema_name 'src_create',
    table_name 'stg_billable_efforts_approveds'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_billable_efforts_approveds ALTER COLUMN _id OPTIONS (
    column_name '_id'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_billable_efforts_approveds ALTER COLUMN "employeeObjId" OPTIONS (
    column_name 'employeeObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_billable_efforts_approveds ALTER COLUMN month OPTIONS (
    column_name 'month'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_billable_efforts_approveds ALTER COLUMN "pODObjId" OPTIONS (
    column_name 'pODObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_billable_efforts_approveds ALTER COLUMN "rowKey" OPTIONS (
    column_name 'rowKey'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_billable_efforts_approveds ALTER COLUMN year OPTIONS (
    column_name 'year'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_billable_efforts_approveds ALTER COLUMN "createdAt" OPTIONS (
    column_name 'createdAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_billable_efforts_approveds ALTER COLUMN "createdBy" OPTIONS (
    column_name 'createdBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_billable_efforts_approveds ALTER COLUMN "departmentObjId" OPTIONS (
    column_name 'departmentObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_billable_efforts_approveds ALTER COLUMN effort OPTIONS (
    column_name 'effort'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_billable_efforts_approveds ALTER COLUMN "isDeleted" OPTIONS (
    column_name 'isDeleted'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_billable_efforts_approveds ALTER COLUMN note OPTIONS (
    column_name 'note'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_billable_efforts_approveds ALTER COLUMN role OPTIONS (
    column_name 'role'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_billable_efforts_approveds ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_billable_efforts_approveds ALTER COLUMN "updatedAt" OPTIONS (
    column_name 'updatedAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_billable_efforts_approveds ALTER COLUMN "updatedBy" OPTIONS (
    column_name 'updatedBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_billable_efforts_approveds ALTER COLUMN "departmentVendor" OPTIONS (
    column_name 'departmentVendor'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_billable_efforts_approveds ALTER COLUMN "isVendor" OPTIONS (
    column_name 'isVendor'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_billable_efforts_approveds ALTER COLUMN type OPTIONS (
    column_name 'type'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_billable_efforts_approveds ALTER COLUMN username OPTIONS (
    column_name 'username'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_billable_efforts_approveds ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE create_fdw.stg_billable_efforts_approveds OWNER TO dev_user;

--
-- Name: stg_branches; Type: FOREIGN TABLE; Schema: create_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE create_fdw.stg_branches (
    _id text,
    "branchAddress" text,
    status text,
    "order" bigint,
    "isDeleted" text,
    "branchName" text,
    "branchCode" text,
    "createdAt" text,
    "createdBy" text,
    "isHidden" text,
    etl_datetime timestamp without time zone
)
SERVER staging_server
OPTIONS (
    schema_name 'src_create',
    table_name 'stg_branches'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_branches ALTER COLUMN _id OPTIONS (
    column_name '_id'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_branches ALTER COLUMN "branchAddress" OPTIONS (
    column_name 'branchAddress'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_branches ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_branches ALTER COLUMN "order" OPTIONS (
    column_name 'order'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_branches ALTER COLUMN "isDeleted" OPTIONS (
    column_name 'isDeleted'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_branches ALTER COLUMN "branchName" OPTIONS (
    column_name 'branchName'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_branches ALTER COLUMN "branchCode" OPTIONS (
    column_name 'branchCode'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_branches ALTER COLUMN "createdAt" OPTIONS (
    column_name 'createdAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_branches ALTER COLUMN "createdBy" OPTIONS (
    column_name 'createdBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_branches ALTER COLUMN "isHidden" OPTIONS (
    column_name 'isHidden'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_branches ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE create_fdw.stg_branches OWNER TO dev_user;

--
-- Name: stg_company_departments; Type: FOREIGN TABLE; Schema: create_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE create_fdw.stg_company_departments (
    _id text,
    "departmentCode" text,
    "departmentDescription" text,
    level bigint,
    children text,
    "departmentType" text,
    status text,
    "order" double precision,
    "isDeleted" text,
    "departmentName" text,
    "parentObjId" text,
    "departmentTypeObjId" text,
    note text,
    "createdAt" text,
    "createdBy" text,
    "branchObjId" text,
    "isHidden" text,
    "accessedDepartments" text,
    "updatedAt" text,
    "updatedBy" text,
    "MISACode" text,
    "OrganizationUnitId" text,
    "OrganizationUnitName" text,
    "managerObjId" text,
    "departmentTypeLevel" text,
    etl_datetime timestamp without time zone
)
SERVER staging_server
OPTIONS (
    schema_name 'src_create',
    table_name 'stg_company_departments'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_company_departments ALTER COLUMN _id OPTIONS (
    column_name '_id'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_company_departments ALTER COLUMN "departmentCode" OPTIONS (
    column_name 'departmentCode'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_company_departments ALTER COLUMN "departmentDescription" OPTIONS (
    column_name 'departmentDescription'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_company_departments ALTER COLUMN level OPTIONS (
    column_name 'level'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_company_departments ALTER COLUMN children OPTIONS (
    column_name 'children'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_company_departments ALTER COLUMN "departmentType" OPTIONS (
    column_name 'departmentType'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_company_departments ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_company_departments ALTER COLUMN "order" OPTIONS (
    column_name 'order'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_company_departments ALTER COLUMN "isDeleted" OPTIONS (
    column_name 'isDeleted'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_company_departments ALTER COLUMN "departmentName" OPTIONS (
    column_name 'departmentName'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_company_departments ALTER COLUMN "parentObjId" OPTIONS (
    column_name 'parentObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_company_departments ALTER COLUMN "departmentTypeObjId" OPTIONS (
    column_name 'departmentTypeObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_company_departments ALTER COLUMN note OPTIONS (
    column_name 'note'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_company_departments ALTER COLUMN "createdAt" OPTIONS (
    column_name 'createdAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_company_departments ALTER COLUMN "createdBy" OPTIONS (
    column_name 'createdBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_company_departments ALTER COLUMN "branchObjId" OPTIONS (
    column_name 'branchObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_company_departments ALTER COLUMN "isHidden" OPTIONS (
    column_name 'isHidden'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_company_departments ALTER COLUMN "accessedDepartments" OPTIONS (
    column_name 'accessedDepartments'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_company_departments ALTER COLUMN "updatedAt" OPTIONS (
    column_name 'updatedAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_company_departments ALTER COLUMN "updatedBy" OPTIONS (
    column_name 'updatedBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_company_departments ALTER COLUMN "MISACode" OPTIONS (
    column_name 'MISACode'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_company_departments ALTER COLUMN "OrganizationUnitId" OPTIONS (
    column_name 'OrganizationUnitId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_company_departments ALTER COLUMN "OrganizationUnitName" OPTIONS (
    column_name 'OrganizationUnitName'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_company_departments ALTER COLUMN "managerObjId" OPTIONS (
    column_name 'managerObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_company_departments ALTER COLUMN "departmentTypeLevel" OPTIONS (
    column_name 'departmentTypeLevel'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_company_departments ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE create_fdw.stg_company_departments OWNER TO dev_user;

--
-- Name: stg_pods; Type: FOREIGN TABLE; Schema: create_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE create_fdw.stg_pods (
    _id text,
    "projectCode" text,
    "projectName" text,
    "projectType" text,
    "projectSize" text,
    "projectRank" text,
    "startDate" text,
    "planUATDate" text,
    "planReleaseDate" text,
    "finalReleaseDate" text,
    "warrantyCondition" text,
    "projectOverview" text,
    "developmentModel" text,
    "jiraUrl" text,
    "weUrl" text,
    "gitUrl" text,
    "statusPOD" text,
    status text,
    "order" bigint,
    "isDeleted" text,
    "departmentObjId" text,
    "pmObjId" text,
    "saleObjId" text,
    "customerObjId" text,
    domain text,
    "createdAt" text,
    "createdBy" text,
    "updatedAt" text,
    "updatedBy" double precision,
    "referList" text,
    "marketObjId" text,
    "projectCategory" text,
    "subPmObjId" text,
    etl_datetime timestamp without time zone
)
SERVER staging_server
OPTIONS (
    schema_name 'src_create',
    table_name 'stg_pods'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN _id OPTIONS (
    column_name '_id'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "projectCode" OPTIONS (
    column_name 'projectCode'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "projectName" OPTIONS (
    column_name 'projectName'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "projectType" OPTIONS (
    column_name 'projectType'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "projectSize" OPTIONS (
    column_name 'projectSize'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "projectRank" OPTIONS (
    column_name 'projectRank'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "startDate" OPTIONS (
    column_name 'startDate'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "planUATDate" OPTIONS (
    column_name 'planUATDate'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "planReleaseDate" OPTIONS (
    column_name 'planReleaseDate'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "finalReleaseDate" OPTIONS (
    column_name 'finalReleaseDate'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "warrantyCondition" OPTIONS (
    column_name 'warrantyCondition'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "projectOverview" OPTIONS (
    column_name 'projectOverview'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "developmentModel" OPTIONS (
    column_name 'developmentModel'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "jiraUrl" OPTIONS (
    column_name 'jiraUrl'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "weUrl" OPTIONS (
    column_name 'weUrl'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "gitUrl" OPTIONS (
    column_name 'gitUrl'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "statusPOD" OPTIONS (
    column_name 'statusPOD'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "order" OPTIONS (
    column_name 'order'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "isDeleted" OPTIONS (
    column_name 'isDeleted'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "departmentObjId" OPTIONS (
    column_name 'departmentObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "pmObjId" OPTIONS (
    column_name 'pmObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "saleObjId" OPTIONS (
    column_name 'saleObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "customerObjId" OPTIONS (
    column_name 'customerObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN domain OPTIONS (
    column_name 'domain'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "createdAt" OPTIONS (
    column_name 'createdAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "createdBy" OPTIONS (
    column_name 'createdBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "updatedAt" OPTIONS (
    column_name 'updatedAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "updatedBy" OPTIONS (
    column_name 'updatedBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "referList" OPTIONS (
    column_name 'referList'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "marketObjId" OPTIONS (
    column_name 'marketObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "projectCategory" OPTIONS (
    column_name 'projectCategory'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN "subPmObjId" OPTIONS (
    column_name 'subPmObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_pods ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE create_fdw.stg_pods OWNER TO dev_user;

--
-- Name: stg_profit_loss_expenses; Type: FOREIGN TABLE; Schema: create_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE create_fdw.stg_profit_loss_expenses (
    _id text,
    "staffCode" text,
    "branchObjId" text,
    "departmentObjId" text,
    "userObjId" text,
    "profitType" text,
    "projectObjId" text,
    "profitLossInvoiceObjId" text,
    value double precision,
    value1 bigint,
    description text,
    type text,
    "infoOther" text,
    "userPositionObjId" text,
    "userLevel" text,
    status text,
    "order" bigint,
    "isDeleted" text,
    "monthAt" text,
    "configCode" text,
    "closingMonthObjId" text,
    "configObjId" text,
    "createdAt" text,
    "createdBy" text,
    info text,
    etl_datetime timestamp without time zone
)
SERVER staging_server
OPTIONS (
    schema_name 'src_create',
    table_name 'stg_profit_loss_expenses'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_expenses ALTER COLUMN _id OPTIONS (
    column_name '_id'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_expenses ALTER COLUMN "staffCode" OPTIONS (
    column_name 'staffCode'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_expenses ALTER COLUMN "branchObjId" OPTIONS (
    column_name 'branchObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_expenses ALTER COLUMN "departmentObjId" OPTIONS (
    column_name 'departmentObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_expenses ALTER COLUMN "userObjId" OPTIONS (
    column_name 'userObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_expenses ALTER COLUMN "profitType" OPTIONS (
    column_name 'profitType'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_expenses ALTER COLUMN "projectObjId" OPTIONS (
    column_name 'projectObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_expenses ALTER COLUMN "profitLossInvoiceObjId" OPTIONS (
    column_name 'profitLossInvoiceObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_expenses ALTER COLUMN value OPTIONS (
    column_name 'value'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_expenses ALTER COLUMN value1 OPTIONS (
    column_name 'value1'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_expenses ALTER COLUMN description OPTIONS (
    column_name 'description'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_expenses ALTER COLUMN type OPTIONS (
    column_name 'type'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_expenses ALTER COLUMN "infoOther" OPTIONS (
    column_name 'infoOther'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_expenses ALTER COLUMN "userPositionObjId" OPTIONS (
    column_name 'userPositionObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_expenses ALTER COLUMN "userLevel" OPTIONS (
    column_name 'userLevel'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_expenses ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_expenses ALTER COLUMN "order" OPTIONS (
    column_name 'order'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_expenses ALTER COLUMN "isDeleted" OPTIONS (
    column_name 'isDeleted'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_expenses ALTER COLUMN "monthAt" OPTIONS (
    column_name 'monthAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_expenses ALTER COLUMN "configCode" OPTIONS (
    column_name 'configCode'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_expenses ALTER COLUMN "closingMonthObjId" OPTIONS (
    column_name 'closingMonthObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_expenses ALTER COLUMN "configObjId" OPTIONS (
    column_name 'configObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_expenses ALTER COLUMN "createdAt" OPTIONS (
    column_name 'createdAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_expenses ALTER COLUMN "createdBy" OPTIONS (
    column_name 'createdBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_expenses ALTER COLUMN info OPTIONS (
    column_name 'info'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_expenses ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE create_fdw.stg_profit_loss_expenses OWNER TO dev_user;

--
-- Name: stg_profit_loss_project_expenses; Type: FOREIGN TABLE; Schema: create_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE create_fdw.stg_profit_loss_project_expenses (
    _id text,
    "staffCode" double precision,
    "branchObjId" text,
    "departmentObjId" text,
    "userObjId" text,
    "profitLossInvoiceObjId" text,
    value double precision,
    value1 bigint,
    description text,
    type text,
    status text,
    "order" bigint,
    "isDeleted" text,
    "monthAt" text,
    "configCode" text,
    "projectObjId" text,
    "closingMonthObjId" text,
    "configObjId" text,
    "createdAt" text,
    "createdBy" text,
    "updatedAt" text,
    "updatedBy" text,
    info text,
    etl_datetime timestamp without time zone
)
SERVER staging_server
OPTIONS (
    schema_name 'src_create',
    table_name 'stg_profit_loss_project_expenses'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_project_expenses ALTER COLUMN _id OPTIONS (
    column_name '_id'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_project_expenses ALTER COLUMN "staffCode" OPTIONS (
    column_name 'staffCode'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_project_expenses ALTER COLUMN "branchObjId" OPTIONS (
    column_name 'branchObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_project_expenses ALTER COLUMN "departmentObjId" OPTIONS (
    column_name 'departmentObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_project_expenses ALTER COLUMN "userObjId" OPTIONS (
    column_name 'userObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_project_expenses ALTER COLUMN "profitLossInvoiceObjId" OPTIONS (
    column_name 'profitLossInvoiceObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_project_expenses ALTER COLUMN value OPTIONS (
    column_name 'value'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_project_expenses ALTER COLUMN value1 OPTIONS (
    column_name 'value1'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_project_expenses ALTER COLUMN description OPTIONS (
    column_name 'description'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_project_expenses ALTER COLUMN type OPTIONS (
    column_name 'type'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_project_expenses ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_project_expenses ALTER COLUMN "order" OPTIONS (
    column_name 'order'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_project_expenses ALTER COLUMN "isDeleted" OPTIONS (
    column_name 'isDeleted'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_project_expenses ALTER COLUMN "monthAt" OPTIONS (
    column_name 'monthAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_project_expenses ALTER COLUMN "configCode" OPTIONS (
    column_name 'configCode'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_project_expenses ALTER COLUMN "projectObjId" OPTIONS (
    column_name 'projectObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_project_expenses ALTER COLUMN "closingMonthObjId" OPTIONS (
    column_name 'closingMonthObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_project_expenses ALTER COLUMN "configObjId" OPTIONS (
    column_name 'configObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_project_expenses ALTER COLUMN "createdAt" OPTIONS (
    column_name 'createdAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_project_expenses ALTER COLUMN "createdBy" OPTIONS (
    column_name 'createdBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_project_expenses ALTER COLUMN "updatedAt" OPTIONS (
    column_name 'updatedAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_project_expenses ALTER COLUMN "updatedBy" OPTIONS (
    column_name 'updatedBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_project_expenses ALTER COLUMN info OPTIONS (
    column_name 'info'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_profit_loss_project_expenses ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE create_fdw.stg_profit_loss_project_expenses OWNER TO dev_user;

--
-- Name: stg_project_categories; Type: FOREIGN TABLE; Schema: create_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE create_fdw.stg_project_categories (
    _id text,
    note text,
    status text,
    "order" bigint,
    "isDeleted" text,
    "projectCategoryName" text,
    "projectCategoryDescription" text,
    "projectCategoryJiraUrl" text,
    "createdAt" text,
    "createdBy" text,
    "jiraCategoryId" bigint,
    "updatedAt" text,
    "updatedBy" text,
    "jiraType" text,
    etl_datetime timestamp without time zone
)
SERVER staging_server
OPTIONS (
    schema_name 'src_create',
    table_name 'stg_project_categories'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_categories ALTER COLUMN _id OPTIONS (
    column_name '_id'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_categories ALTER COLUMN note OPTIONS (
    column_name 'note'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_categories ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_categories ALTER COLUMN "order" OPTIONS (
    column_name 'order'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_categories ALTER COLUMN "isDeleted" OPTIONS (
    column_name 'isDeleted'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_categories ALTER COLUMN "projectCategoryName" OPTIONS (
    column_name 'projectCategoryName'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_categories ALTER COLUMN "projectCategoryDescription" OPTIONS (
    column_name 'projectCategoryDescription'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_categories ALTER COLUMN "projectCategoryJiraUrl" OPTIONS (
    column_name 'projectCategoryJiraUrl'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_categories ALTER COLUMN "createdAt" OPTIONS (
    column_name 'createdAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_categories ALTER COLUMN "createdBy" OPTIONS (
    column_name 'createdBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_categories ALTER COLUMN "jiraCategoryId" OPTIONS (
    column_name 'jiraCategoryId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_categories ALTER COLUMN "updatedAt" OPTIONS (
    column_name 'updatedAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_categories ALTER COLUMN "updatedBy" OPTIONS (
    column_name 'updatedBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_categories ALTER COLUMN "jiraType" OPTIONS (
    column_name 'jiraType'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_categories ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE create_fdw.stg_project_categories OWNER TO dev_user;

--
-- Name: stg_project_members; Type: FOREIGN TABLE; Schema: create_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE create_fdw.stg_project_members (
    _id text,
    "projectPositionObjIds" text,
    note text,
    status text,
    "order" bigint,
    "isDeleted" text,
    "projectObjId" text,
    "userObjId" text,
    description text,
    "joinedAt" text,
    "leftAt" text,
    "createdAt" text,
    "updatedAt" text,
    "updatedBy" text,
    "createdBy" text,
    level double precision,
    etl_datetime timestamp without time zone
)
SERVER staging_server
OPTIONS (
    schema_name 'src_create',
    table_name 'stg_project_members'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_members ALTER COLUMN _id OPTIONS (
    column_name '_id'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_members ALTER COLUMN "projectPositionObjIds" OPTIONS (
    column_name 'projectPositionObjIds'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_members ALTER COLUMN note OPTIONS (
    column_name 'note'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_members ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_members ALTER COLUMN "order" OPTIONS (
    column_name 'order'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_members ALTER COLUMN "isDeleted" OPTIONS (
    column_name 'isDeleted'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_members ALTER COLUMN "projectObjId" OPTIONS (
    column_name 'projectObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_members ALTER COLUMN "userObjId" OPTIONS (
    column_name 'userObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_members ALTER COLUMN description OPTIONS (
    column_name 'description'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_members ALTER COLUMN "joinedAt" OPTIONS (
    column_name 'joinedAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_members ALTER COLUMN "leftAt" OPTIONS (
    column_name 'leftAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_members ALTER COLUMN "createdAt" OPTIONS (
    column_name 'createdAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_members ALTER COLUMN "updatedAt" OPTIONS (
    column_name 'updatedAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_members ALTER COLUMN "updatedBy" OPTIONS (
    column_name 'updatedBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_members ALTER COLUMN "createdBy" OPTIONS (
    column_name 'createdBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_members ALTER COLUMN level OPTIONS (
    column_name 'level'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_project_members ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE create_fdw.stg_project_members OWNER TO dev_user;

--
-- Name: stg_projects; Type: FOREIGN TABLE; Schema: create_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE create_fdw.stg_projects (
    _id text,
    "projectCategoryObjId" text,
    note text,
    status text,
    "order" bigint,
    "isDeleted" text,
    "projectName" text,
    "projectCode" text,
    "projectStatus" text,
    "projectJiraUrl" text,
    "projectDescription" text,
    "createdAt" text,
    "createdBy" text,
    "jiraProjectId" double precision,
    "jiraProjectKey" text,
    "projectType" text,
    "jiraType" text,
    "projectLeadObjId" text,
    "updatedAt" text,
    "updatedBy" text,
    type text,
    "flagCron" text,
    "dataType" text,
    "projectTypeKeyJira" text,
    "projectCustomerCode" double precision,
    "projectObjective" text,
    "projectOverView" text,
    "projectRank" text,
    "projectScope" text,
    "totalBillEffort" double precision,
    "totalIntBillEffort" double precision,
    "endAt" text,
    "startAt" text,
    "releaseAt" text,
    "podLink" text,
    "podWe" text,
    "projectDiv" double precision,
    "projectChildObjIds" text,
    etl_datetime timestamp without time zone
)
SERVER staging_server
OPTIONS (
    schema_name 'src_create',
    table_name 'stg_projects'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN _id OPTIONS (
    column_name '_id'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "projectCategoryObjId" OPTIONS (
    column_name 'projectCategoryObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN note OPTIONS (
    column_name 'note'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "order" OPTIONS (
    column_name 'order'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "isDeleted" OPTIONS (
    column_name 'isDeleted'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "projectName" OPTIONS (
    column_name 'projectName'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "projectCode" OPTIONS (
    column_name 'projectCode'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "projectStatus" OPTIONS (
    column_name 'projectStatus'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "projectJiraUrl" OPTIONS (
    column_name 'projectJiraUrl'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "projectDescription" OPTIONS (
    column_name 'projectDescription'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "createdAt" OPTIONS (
    column_name 'createdAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "createdBy" OPTIONS (
    column_name 'createdBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "jiraProjectId" OPTIONS (
    column_name 'jiraProjectId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "jiraProjectKey" OPTIONS (
    column_name 'jiraProjectKey'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "projectType" OPTIONS (
    column_name 'projectType'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "jiraType" OPTIONS (
    column_name 'jiraType'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "projectLeadObjId" OPTIONS (
    column_name 'projectLeadObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "updatedAt" OPTIONS (
    column_name 'updatedAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "updatedBy" OPTIONS (
    column_name 'updatedBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN type OPTIONS (
    column_name 'type'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "flagCron" OPTIONS (
    column_name 'flagCron'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "dataType" OPTIONS (
    column_name 'dataType'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "projectTypeKeyJira" OPTIONS (
    column_name 'projectTypeKeyJira'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "projectCustomerCode" OPTIONS (
    column_name 'projectCustomerCode'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "projectObjective" OPTIONS (
    column_name 'projectObjective'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "projectOverView" OPTIONS (
    column_name 'projectOverView'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "projectRank" OPTIONS (
    column_name 'projectRank'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "projectScope" OPTIONS (
    column_name 'projectScope'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "totalBillEffort" OPTIONS (
    column_name 'totalBillEffort'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "totalIntBillEffort" OPTIONS (
    column_name 'totalIntBillEffort'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "endAt" OPTIONS (
    column_name 'endAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "startAt" OPTIONS (
    column_name 'startAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "releaseAt" OPTIONS (
    column_name 'releaseAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "podLink" OPTIONS (
    column_name 'podLink'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "podWe" OPTIONS (
    column_name 'podWe'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "projectDiv" OPTIONS (
    column_name 'projectDiv'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN "projectChildObjIds" OPTIONS (
    column_name 'projectChildObjIds'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_projects ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE create_fdw.stg_projects OWNER TO dev_user;

--
-- Name: stg_salaries; Type: FOREIGN TABLE; Schema: create_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE create_fdw.stg_salaries (
    _id text,
    "closingMonthObjId" text,
    "userObjId" text,
    "createdAt" text,
    "createdBy" text,
    insurance text,
    "isDeleted" text,
    "order" bigint,
    "salaryBasic" text,
    status text,
    "totalSalary" text,
    "updatedBy" text,
    "userInfoBlock" text,
    "editUserObjId" text,
    "updatedAt" text,
    note text,
    etl_datetime timestamp without time zone
)
SERVER staging_server
OPTIONS (
    schema_name 'src_create',
    table_name 'stg_salaries'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_salaries ALTER COLUMN _id OPTIONS (
    column_name '_id'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_salaries ALTER COLUMN "closingMonthObjId" OPTIONS (
    column_name 'closingMonthObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_salaries ALTER COLUMN "userObjId" OPTIONS (
    column_name 'userObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_salaries ALTER COLUMN "createdAt" OPTIONS (
    column_name 'createdAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_salaries ALTER COLUMN "createdBy" OPTIONS (
    column_name 'createdBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_salaries ALTER COLUMN insurance OPTIONS (
    column_name 'insurance'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_salaries ALTER COLUMN "isDeleted" OPTIONS (
    column_name 'isDeleted'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_salaries ALTER COLUMN "order" OPTIONS (
    column_name 'order'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_salaries ALTER COLUMN "salaryBasic" OPTIONS (
    column_name 'salaryBasic'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_salaries ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_salaries ALTER COLUMN "totalSalary" OPTIONS (
    column_name 'totalSalary'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_salaries ALTER COLUMN "updatedBy" OPTIONS (
    column_name 'updatedBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_salaries ALTER COLUMN "userInfoBlock" OPTIONS (
    column_name 'userInfoBlock'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_salaries ALTER COLUMN "editUserObjId" OPTIONS (
    column_name 'editUserObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_salaries ALTER COLUMN "updatedAt" OPTIONS (
    column_name 'updatedAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_salaries ALTER COLUMN note OPTIONS (
    column_name 'note'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_salaries ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE create_fdw.stg_salaries OWNER TO dev_user;

--
-- Name: stg_staff_attendance_types; Type: FOREIGN TABLE; Schema: create_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE create_fdw.stg_staff_attendance_types (
    _id text,
    "attendanceTypeName" text,
    "attendanceTypeCode" text,
    "attendanceWorkDay" bigint,
    "attendanceTypeID" text,
    status text,
    "order" bigint,
    "isDeleted" text,
    "createdAt" text,
    "createdBy" text,
    "isUsed" text,
    type text,
    "unitStatus" text,
    "unitType" text,
    "unitValue" double precision,
    "updatedAt" text,
    "updatedBy" text,
    "attendanceName" text,
    note text,
    etl_datetime timestamp without time zone
)
SERVER staging_server
OPTIONS (
    schema_name 'src_create',
    table_name 'stg_staff_attendance_types'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendance_types ALTER COLUMN _id OPTIONS (
    column_name '_id'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendance_types ALTER COLUMN "attendanceTypeName" OPTIONS (
    column_name 'attendanceTypeName'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendance_types ALTER COLUMN "attendanceTypeCode" OPTIONS (
    column_name 'attendanceTypeCode'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendance_types ALTER COLUMN "attendanceWorkDay" OPTIONS (
    column_name 'attendanceWorkDay'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendance_types ALTER COLUMN "attendanceTypeID" OPTIONS (
    column_name 'attendanceTypeID'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendance_types ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendance_types ALTER COLUMN "order" OPTIONS (
    column_name 'order'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendance_types ALTER COLUMN "isDeleted" OPTIONS (
    column_name 'isDeleted'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendance_types ALTER COLUMN "createdAt" OPTIONS (
    column_name 'createdAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendance_types ALTER COLUMN "createdBy" OPTIONS (
    column_name 'createdBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendance_types ALTER COLUMN "isUsed" OPTIONS (
    column_name 'isUsed'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendance_types ALTER COLUMN type OPTIONS (
    column_name 'type'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendance_types ALTER COLUMN "unitStatus" OPTIONS (
    column_name 'unitStatus'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendance_types ALTER COLUMN "unitType" OPTIONS (
    column_name 'unitType'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendance_types ALTER COLUMN "unitValue" OPTIONS (
    column_name 'unitValue'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendance_types ALTER COLUMN "updatedAt" OPTIONS (
    column_name 'updatedAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendance_types ALTER COLUMN "updatedBy" OPTIONS (
    column_name 'updatedBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendance_types ALTER COLUMN "attendanceName" OPTIONS (
    column_name 'attendanceName'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendance_types ALTER COLUMN note OPTIONS (
    column_name 'note'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendance_types ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE create_fdw.stg_staff_attendance_types OWNER TO dev_user;

--
-- Name: stg_staff_attendances; Type: FOREIGN TABLE; Schema: create_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE create_fdw.stg_staff_attendances (
    _id text,
    "relationshipObjIds" text,
    "substituteObjId" text,
    "fromDate" text,
    "endDate" text,
    "absentDay" double precision,
    reason text,
    "statusApproval" text,
    "dateApproval" text,
    comment text,
    "attendanceID" text,
    type text,
    "lateInFirstHalfShift" double precision,
    "earlyOutFirstHaftShift" text,
    "lateInLastHalfShift" text,
    "earlyOutLastHalfShift" double precision,
    "applyFor" text,
    status text,
    "order" bigint,
    "isDeleted" text,
    "userObjId" text,
    "attendanceTypeObjId" text,
    "reportObjId" text,
    "createdAt" text,
    "createdBy" text,
    "flagCron" text,
    "leavesApproval" double precision,
    "attendanceState" text,
    "flagCrawler" text,
    "absentDayPresent" double precision,
    "absentDayFuture" double precision,
    "absentDayDetail" text,
    note text,
    "userApprovalObjId" text,
    "remainDay" double precision,
    "leftDay" double precision,
    "totalLeaveDay" double precision,
    "updatedAt" text,
    "updatedBy" text,
    "totalLeaveDayRaw" double precision,
    "leftDayRaw" double precision,
    "remainDayRaw" double precision,
    etl_datetime timestamp without time zone
)
SERVER staging_server
OPTIONS (
    schema_name 'src_create',
    table_name 'stg_staff_attendances'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN _id OPTIONS (
    column_name '_id'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "relationshipObjIds" OPTIONS (
    column_name 'relationshipObjIds'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "substituteObjId" OPTIONS (
    column_name 'substituteObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "fromDate" OPTIONS (
    column_name 'fromDate'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "endDate" OPTIONS (
    column_name 'endDate'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "absentDay" OPTIONS (
    column_name 'absentDay'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN reason OPTIONS (
    column_name 'reason'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "statusApproval" OPTIONS (
    column_name 'statusApproval'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "dateApproval" OPTIONS (
    column_name 'dateApproval'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN comment OPTIONS (
    column_name 'comment'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "attendanceID" OPTIONS (
    column_name 'attendanceID'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN type OPTIONS (
    column_name 'type'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "lateInFirstHalfShift" OPTIONS (
    column_name 'lateInFirstHalfShift'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "earlyOutFirstHaftShift" OPTIONS (
    column_name 'earlyOutFirstHaftShift'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "lateInLastHalfShift" OPTIONS (
    column_name 'lateInLastHalfShift'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "earlyOutLastHalfShift" OPTIONS (
    column_name 'earlyOutLastHalfShift'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "applyFor" OPTIONS (
    column_name 'applyFor'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "order" OPTIONS (
    column_name 'order'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "isDeleted" OPTIONS (
    column_name 'isDeleted'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "userObjId" OPTIONS (
    column_name 'userObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "attendanceTypeObjId" OPTIONS (
    column_name 'attendanceTypeObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "reportObjId" OPTIONS (
    column_name 'reportObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "createdAt" OPTIONS (
    column_name 'createdAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "createdBy" OPTIONS (
    column_name 'createdBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "flagCron" OPTIONS (
    column_name 'flagCron'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "leavesApproval" OPTIONS (
    column_name 'leavesApproval'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "attendanceState" OPTIONS (
    column_name 'attendanceState'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "flagCrawler" OPTIONS (
    column_name 'flagCrawler'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "absentDayPresent" OPTIONS (
    column_name 'absentDayPresent'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "absentDayFuture" OPTIONS (
    column_name 'absentDayFuture'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "absentDayDetail" OPTIONS (
    column_name 'absentDayDetail'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN note OPTIONS (
    column_name 'note'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "userApprovalObjId" OPTIONS (
    column_name 'userApprovalObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "remainDay" OPTIONS (
    column_name 'remainDay'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "leftDay" OPTIONS (
    column_name 'leftDay'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "totalLeaveDay" OPTIONS (
    column_name 'totalLeaveDay'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "updatedAt" OPTIONS (
    column_name 'updatedAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "updatedBy" OPTIONS (
    column_name 'updatedBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "totalLeaveDayRaw" OPTIONS (
    column_name 'totalLeaveDayRaw'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "leftDayRaw" OPTIONS (
    column_name 'leftDayRaw'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN "remainDayRaw" OPTIONS (
    column_name 'remainDayRaw'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_staff_attendances ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE create_fdw.stg_staff_attendances OWNER TO dev_user;

--
-- Name: stg_user_infos; Type: FOREIGN TABLE; Schema: create_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE create_fdw.stg_user_infos (
    _id text,
    "staffCode" double precision,
    "firstName" text,
    "middleName" text,
    "lastName" text,
    "emailCompany" text,
    "emailPersonal" text,
    "birthDay" text,
    "welcomeDay" double precision,
    gender text,
    "mobileCountryCode" text,
    mobile text,
    "officeTel" text,
    address text,
    note text,
    "userJobStatus" text,
    status text,
    "order" bigint,
    "isDeleted" text,
    "userObjId" text,
    "createdAt" text,
    "createdBy" text,
    "updatedAt" text,
    "updatedBy" text,
    "employeeID" text,
    "flagCron" text,
    "officialDate" text,
    "probationDate" text,
    "organizationUnitID" text,
    "organizationUnitName" text,
    "internDate" text,
    "dataType" text,
    "MISACode" text,
    "quitDate" text,
    "timekeepingDate" text,
    "welcomeDate" text,
    etl_datetime timestamp without time zone
)
SERVER staging_server
OPTIONS (
    schema_name 'src_create',
    table_name 'stg_user_infos'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN _id OPTIONS (
    column_name '_id'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "staffCode" OPTIONS (
    column_name 'staffCode'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "firstName" OPTIONS (
    column_name 'firstName'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "middleName" OPTIONS (
    column_name 'middleName'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "lastName" OPTIONS (
    column_name 'lastName'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "emailCompany" OPTIONS (
    column_name 'emailCompany'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "emailPersonal" OPTIONS (
    column_name 'emailPersonal'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "birthDay" OPTIONS (
    column_name 'birthDay'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "welcomeDay" OPTIONS (
    column_name 'welcomeDay'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN gender OPTIONS (
    column_name 'gender'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "mobileCountryCode" OPTIONS (
    column_name 'mobileCountryCode'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN mobile OPTIONS (
    column_name 'mobile'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "officeTel" OPTIONS (
    column_name 'officeTel'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN address OPTIONS (
    column_name 'address'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN note OPTIONS (
    column_name 'note'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "userJobStatus" OPTIONS (
    column_name 'userJobStatus'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "order" OPTIONS (
    column_name 'order'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "isDeleted" OPTIONS (
    column_name 'isDeleted'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "userObjId" OPTIONS (
    column_name 'userObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "createdAt" OPTIONS (
    column_name 'createdAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "createdBy" OPTIONS (
    column_name 'createdBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "updatedAt" OPTIONS (
    column_name 'updatedAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "updatedBy" OPTIONS (
    column_name 'updatedBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "employeeID" OPTIONS (
    column_name 'employeeID'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "flagCron" OPTIONS (
    column_name 'flagCron'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "officialDate" OPTIONS (
    column_name 'officialDate'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "probationDate" OPTIONS (
    column_name 'probationDate'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "organizationUnitID" OPTIONS (
    column_name 'organizationUnitID'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "organizationUnitName" OPTIONS (
    column_name 'organizationUnitName'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "internDate" OPTIONS (
    column_name 'internDate'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "dataType" OPTIONS (
    column_name 'dataType'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "MISACode" OPTIONS (
    column_name 'MISACode'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "quitDate" OPTIONS (
    column_name 'quitDate'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "timekeepingDate" OPTIONS (
    column_name 'timekeepingDate'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN "welcomeDate" OPTIONS (
    column_name 'welcomeDate'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_infos ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE create_fdw.stg_user_infos OWNER TO dev_user;

--
-- Name: stg_user_positions; Type: FOREIGN TABLE; Schema: create_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE create_fdw.stg_user_positions (
    _id text,
    status text,
    "order" bigint,
    "isDeleted" text,
    "positionName" text,
    "positionCode" text,
    "positionDescription" text,
    "createdAt" text,
    "createdBy" text,
    "updatedAt" text,
    "updatedBy" text,
    "positionStatus" text,
    "positionLevel" double precision,
    "eLearningGroupPositionObjId" text,
    type text,
    etl_datetime timestamp without time zone
)
SERVER staging_server
OPTIONS (
    schema_name 'src_create',
    table_name 'stg_user_positions'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_positions ALTER COLUMN _id OPTIONS (
    column_name '_id'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_positions ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_positions ALTER COLUMN "order" OPTIONS (
    column_name 'order'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_positions ALTER COLUMN "isDeleted" OPTIONS (
    column_name 'isDeleted'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_positions ALTER COLUMN "positionName" OPTIONS (
    column_name 'positionName'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_positions ALTER COLUMN "positionCode" OPTIONS (
    column_name 'positionCode'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_positions ALTER COLUMN "positionDescription" OPTIONS (
    column_name 'positionDescription'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_positions ALTER COLUMN "createdAt" OPTIONS (
    column_name 'createdAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_positions ALTER COLUMN "createdBy" OPTIONS (
    column_name 'createdBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_positions ALTER COLUMN "updatedAt" OPTIONS (
    column_name 'updatedAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_positions ALTER COLUMN "updatedBy" OPTIONS (
    column_name 'updatedBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_positions ALTER COLUMN "positionStatus" OPTIONS (
    column_name 'positionStatus'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_positions ALTER COLUMN "positionLevel" OPTIONS (
    column_name 'positionLevel'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_positions ALTER COLUMN "eLearningGroupPositionObjId" OPTIONS (
    column_name 'eLearningGroupPositionObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_positions ALTER COLUMN type OPTIONS (
    column_name 'type'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_positions ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE create_fdw.stg_user_positions OWNER TO dev_user;

--
-- Name: stg_user_skills; Type: FOREIGN TABLE; Schema: create_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE create_fdw.stg_user_skills (
    _id text,
    status text,
    "order" bigint,
    "isDeleted" text,
    "userObjId" text,
    "userSkills" text,
    "createdAt" text,
    "createdBy" text,
    etl_datetime timestamp without time zone
)
SERVER staging_server
OPTIONS (
    schema_name 'src_create',
    table_name 'stg_user_skills'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_skills ALTER COLUMN _id OPTIONS (
    column_name '_id'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_skills ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_skills ALTER COLUMN "order" OPTIONS (
    column_name 'order'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_skills ALTER COLUMN "isDeleted" OPTIONS (
    column_name 'isDeleted'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_skills ALTER COLUMN "userObjId" OPTIONS (
    column_name 'userObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_skills ALTER COLUMN "userSkills" OPTIONS (
    column_name 'userSkills'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_skills ALTER COLUMN "createdAt" OPTIONS (
    column_name 'createdAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_skills ALTER COLUMN "createdBy" OPTIONS (
    column_name 'createdBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_user_skills ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE create_fdw.stg_user_skills OWNER TO dev_user;

--
-- Name: stg_users; Type: FOREIGN TABLE; Schema: create_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE create_fdw.stg_users (
    _id text,
    uid text,
    name text,
    "branchObjId" text,
    "userPositionObjId" text,
    mobile double precision,
    jira_user_id double precision,
    note text,
    status text,
    "order" bigint,
    "isDeleted" text,
    username text,
    password text,
    email text,
    "createdAt" text,
    "createdBy" text,
    "staffCode" double precision,
    "mobileCountryCode" double precision,
    "departmentObjId" text,
    "positionObjId" text,
    "updatedAt" text,
    "updatedBy" text,
    "userType" text,
    "userJiraMapping" text,
    "welcomeDay" text,
    "userStatus" text,
    "expiresDate" text,
    "userCode" text,
    "flagCron" text,
    "countFailed" double precision,
    "resetToken" text,
    "nameTag" text,
    level double precision,
    "userLevel" text,
    "userUpdatedAt" text,
    "userSubPositionObjId" text,
    "performanceFactor" double precision,
    "jobObjId" double precision,
    "userJobStatus" text,
    "jiraUserId" double precision,
    "jiraName" text,
    "birthDay" double precision,
    "emailPersonal" double precision,
    gender double precision,
    etl_datetime timestamp without time zone
)
SERVER staging_server
OPTIONS (
    schema_name 'src_create',
    table_name 'stg_users'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN _id OPTIONS (
    column_name '_id'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN uid OPTIONS (
    column_name 'uid'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN name OPTIONS (
    column_name 'name'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "branchObjId" OPTIONS (
    column_name 'branchObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "userPositionObjId" OPTIONS (
    column_name 'userPositionObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN mobile OPTIONS (
    column_name 'mobile'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN jira_user_id OPTIONS (
    column_name 'jira_user_id'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN note OPTIONS (
    column_name 'note'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "order" OPTIONS (
    column_name 'order'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "isDeleted" OPTIONS (
    column_name 'isDeleted'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN username OPTIONS (
    column_name 'username'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN password OPTIONS (
    column_name 'password'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN email OPTIONS (
    column_name 'email'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "createdAt" OPTIONS (
    column_name 'createdAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "createdBy" OPTIONS (
    column_name 'createdBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "staffCode" OPTIONS (
    column_name 'staffCode'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "mobileCountryCode" OPTIONS (
    column_name 'mobileCountryCode'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "departmentObjId" OPTIONS (
    column_name 'departmentObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "positionObjId" OPTIONS (
    column_name 'positionObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "updatedAt" OPTIONS (
    column_name 'updatedAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "updatedBy" OPTIONS (
    column_name 'updatedBy'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "userType" OPTIONS (
    column_name 'userType'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "userJiraMapping" OPTIONS (
    column_name 'userJiraMapping'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "welcomeDay" OPTIONS (
    column_name 'welcomeDay'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "userStatus" OPTIONS (
    column_name 'userStatus'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "expiresDate" OPTIONS (
    column_name 'expiresDate'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "userCode" OPTIONS (
    column_name 'userCode'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "flagCron" OPTIONS (
    column_name 'flagCron'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "countFailed" OPTIONS (
    column_name 'countFailed'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "resetToken" OPTIONS (
    column_name 'resetToken'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "nameTag" OPTIONS (
    column_name 'nameTag'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN level OPTIONS (
    column_name 'level'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "userLevel" OPTIONS (
    column_name 'userLevel'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "userUpdatedAt" OPTIONS (
    column_name 'userUpdatedAt'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "userSubPositionObjId" OPTIONS (
    column_name 'userSubPositionObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "performanceFactor" OPTIONS (
    column_name 'performanceFactor'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "jobObjId" OPTIONS (
    column_name 'jobObjId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "userJobStatus" OPTIONS (
    column_name 'userJobStatus'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "jiraUserId" OPTIONS (
    column_name 'jiraUserId'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "jiraName" OPTIONS (
    column_name 'jiraName'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "birthDay" OPTIONS (
    column_name 'birthDay'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN "emailPersonal" OPTIONS (
    column_name 'emailPersonal'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN gender OPTIONS (
    column_name 'gender'
);
ALTER FOREIGN TABLE ONLY create_fdw.stg_users ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE create_fdw.stg_users OWNER TO dev_user;

--
-- Name: tables; Type: FOREIGN TABLE; Schema: fdw_metadata; Owner: dev_user
--

CREATE FOREIGN TABLE fdw_metadata.tables (
    table_catalog information_schema.sql_identifier,
    table_schema information_schema.sql_identifier,
    table_name information_schema.sql_identifier,
    table_type information_schema.character_data,
    self_referencing_column_name information_schema.sql_identifier,
    reference_generation information_schema.character_data,
    user_defined_type_catalog information_schema.sql_identifier,
    user_defined_type_schema information_schema.sql_identifier,
    user_defined_type_name information_schema.sql_identifier,
    is_insertable_into information_schema.yes_or_no,
    is_typed information_schema.yes_or_no,
    commit_action information_schema.character_data
)
SERVER staging_server
OPTIONS (
    schema_name 'information_schema',
    table_name 'tables'
);
ALTER FOREIGN TABLE ONLY fdw_metadata.tables ALTER COLUMN table_catalog OPTIONS (
    column_name 'table_catalog'
);
ALTER FOREIGN TABLE ONLY fdw_metadata.tables ALTER COLUMN table_schema OPTIONS (
    column_name 'table_schema'
);
ALTER FOREIGN TABLE ONLY fdw_metadata.tables ALTER COLUMN table_name OPTIONS (
    column_name 'table_name'
);
ALTER FOREIGN TABLE ONLY fdw_metadata.tables ALTER COLUMN table_type OPTIONS (
    column_name 'table_type'
);
ALTER FOREIGN TABLE ONLY fdw_metadata.tables ALTER COLUMN self_referencing_column_name OPTIONS (
    column_name 'self_referencing_column_name'
);
ALTER FOREIGN TABLE ONLY fdw_metadata.tables ALTER COLUMN reference_generation OPTIONS (
    column_name 'reference_generation'
);
ALTER FOREIGN TABLE ONLY fdw_metadata.tables ALTER COLUMN user_defined_type_catalog OPTIONS (
    column_name 'user_defined_type_catalog'
);
ALTER FOREIGN TABLE ONLY fdw_metadata.tables ALTER COLUMN user_defined_type_schema OPTIONS (
    column_name 'user_defined_type_schema'
);
ALTER FOREIGN TABLE ONLY fdw_metadata.tables ALTER COLUMN user_defined_type_name OPTIONS (
    column_name 'user_defined_type_name'
);
ALTER FOREIGN TABLE ONLY fdw_metadata.tables ALTER COLUMN is_insertable_into OPTIONS (
    column_name 'is_insertable_into'
);
ALTER FOREIGN TABLE ONLY fdw_metadata.tables ALTER COLUMN is_typed OPTIONS (
    column_name 'is_typed'
);
ALTER FOREIGN TABLE ONLY fdw_metadata.tables ALTER COLUMN commit_action OPTIONS (
    column_name 'commit_action'
);


ALTER FOREIGN TABLE fdw_metadata.tables OWNER TO dev_user;

--
-- Name: stg_issuestatus; Type: FOREIGN TABLE; Schema: jira_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE jira_fdw.stg_issuestatus (
    "ID" text,
    "SEQUENCE" double precision,
    pname text,
    "DESCRIPTION" text,
    "ICONURL" text,
    "STATUSCATEGORY" double precision,
    etl_datetime timestamp without time zone
)
SERVER staging_server
OPTIONS (
    schema_name 'src_jira',
    table_name 'stg_issuestatus'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_issuestatus ALTER COLUMN "ID" OPTIONS (
    column_name 'ID'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_issuestatus ALTER COLUMN "SEQUENCE" OPTIONS (
    column_name 'SEQUENCE'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_issuestatus ALTER COLUMN pname OPTIONS (
    column_name 'pname'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_issuestatus ALTER COLUMN "DESCRIPTION" OPTIONS (
    column_name 'DESCRIPTION'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_issuestatus ALTER COLUMN "ICONURL" OPTIONS (
    column_name 'ICONURL'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_issuestatus ALTER COLUMN "STATUSCATEGORY" OPTIONS (
    column_name 'STATUSCATEGORY'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_issuestatus ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE jira_fdw.stg_issuestatus OWNER TO dev_user;

--
-- Name: stg_issuetype; Type: FOREIGN TABLE; Schema: jira_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE jira_fdw.stg_issuetype (
    "ID" text,
    "SEQUENCE" double precision,
    pname text,
    pstyle text,
    "DESCRIPTION" text,
    "ICONURL" text,
    "AVATAR" double precision,
    etl_datetime timestamp without time zone
)
SERVER staging_server
OPTIONS (
    schema_name 'src_jira',
    table_name 'stg_issuetype'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_issuetype ALTER COLUMN "ID" OPTIONS (
    column_name 'ID'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_issuetype ALTER COLUMN "SEQUENCE" OPTIONS (
    column_name 'SEQUENCE'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_issuetype ALTER COLUMN pname OPTIONS (
    column_name 'pname'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_issuetype ALTER COLUMN pstyle OPTIONS (
    column_name 'pstyle'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_issuetype ALTER COLUMN "DESCRIPTION" OPTIONS (
    column_name 'DESCRIPTION'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_issuetype ALTER COLUMN "ICONURL" OPTIONS (
    column_name 'ICONURL'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_issuetype ALTER COLUMN "AVATAR" OPTIONS (
    column_name 'AVATAR'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_issuetype ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE jira_fdw.stg_issuetype OWNER TO dev_user;

--
-- Name: stg_jiraissue; Type: FOREIGN TABLE; Schema: jira_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE jira_fdw.stg_jiraissue (
    "ID" double precision,
    pkey text,
    issuenum double precision,
    "PROJECT" double precision,
    "REPORTER" text,
    "ASSIGNEE" text,
    "CREATOR" text,
    issuetype text,
    "SUMMARY" text,
    "DESCRIPTION" text,
    "ENVIRONMENT" text,
    "PRIORITY" text,
    "RESOLUTION" text,
    issuestatus text,
    "CREATED" timestamp without time zone,
    "UPDATED" timestamp without time zone,
    "DUEDATE" timestamp without time zone,
    "RESOLUTIONDATE" timestamp without time zone,
    "VOTES" double precision,
    "WATCHES" double precision,
    "TIMEORIGINALESTIMATE" double precision,
    "TIMEESTIMATE" double precision,
    "TIMESPENT" double precision,
    "WORKFLOW_ID" double precision,
    "SECURITY" double precision,
    "FIXFOR" text,
    "COMPONENT" text,
    "ARCHIVED" text,
    "ARCHIVEDBY" text,
    "ARCHIVEDDATE" text,
    etl_datetime timestamp without time zone
)
SERVER staging_server
OPTIONS (
    schema_name 'src_jira',
    table_name 'stg_jiraissue'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN "ID" OPTIONS (
    column_name 'ID'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN pkey OPTIONS (
    column_name 'pkey'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN issuenum OPTIONS (
    column_name 'issuenum'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN "PROJECT" OPTIONS (
    column_name 'PROJECT'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN "REPORTER" OPTIONS (
    column_name 'REPORTER'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN "ASSIGNEE" OPTIONS (
    column_name 'ASSIGNEE'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN "CREATOR" OPTIONS (
    column_name 'CREATOR'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN issuetype OPTIONS (
    column_name 'issuetype'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN "SUMMARY" OPTIONS (
    column_name 'SUMMARY'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN "DESCRIPTION" OPTIONS (
    column_name 'DESCRIPTION'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN "ENVIRONMENT" OPTIONS (
    column_name 'ENVIRONMENT'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN "PRIORITY" OPTIONS (
    column_name 'PRIORITY'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN "RESOLUTION" OPTIONS (
    column_name 'RESOLUTION'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN issuestatus OPTIONS (
    column_name 'issuestatus'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN "CREATED" OPTIONS (
    column_name 'CREATED'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN "UPDATED" OPTIONS (
    column_name 'UPDATED'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN "DUEDATE" OPTIONS (
    column_name 'DUEDATE'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN "RESOLUTIONDATE" OPTIONS (
    column_name 'RESOLUTIONDATE'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN "VOTES" OPTIONS (
    column_name 'VOTES'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN "WATCHES" OPTIONS (
    column_name 'WATCHES'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN "TIMEORIGINALESTIMATE" OPTIONS (
    column_name 'TIMEORIGINALESTIMATE'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN "TIMEESTIMATE" OPTIONS (
    column_name 'TIMEESTIMATE'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN "TIMESPENT" OPTIONS (
    column_name 'TIMESPENT'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN "WORKFLOW_ID" OPTIONS (
    column_name 'WORKFLOW_ID'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN "SECURITY" OPTIONS (
    column_name 'SECURITY'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN "FIXFOR" OPTIONS (
    column_name 'FIXFOR'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN "COMPONENT" OPTIONS (
    column_name 'COMPONENT'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN "ARCHIVED" OPTIONS (
    column_name 'ARCHIVED'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN "ARCHIVEDBY" OPTIONS (
    column_name 'ARCHIVEDBY'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN "ARCHIVEDDATE" OPTIONS (
    column_name 'ARCHIVEDDATE'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_jiraissue ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE jira_fdw.stg_jiraissue OWNER TO dev_user;

--
-- Name: stg_priority; Type: FOREIGN TABLE; Schema: jira_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE jira_fdw.stg_priority (
    "ID" text,
    "SEQUENCE" double precision,
    pname text,
    "DESCRIPTION" text,
    "ICONURL" text,
    "STATUS_COLOR" text,
    etl_datetime timestamp without time zone
)
SERVER staging_server
OPTIONS (
    schema_name 'src_jira',
    table_name 'stg_priority'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_priority ALTER COLUMN "ID" OPTIONS (
    column_name 'ID'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_priority ALTER COLUMN "SEQUENCE" OPTIONS (
    column_name 'SEQUENCE'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_priority ALTER COLUMN pname OPTIONS (
    column_name 'pname'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_priority ALTER COLUMN "DESCRIPTION" OPTIONS (
    column_name 'DESCRIPTION'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_priority ALTER COLUMN "ICONURL" OPTIONS (
    column_name 'ICONURL'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_priority ALTER COLUMN "STATUS_COLOR" OPTIONS (
    column_name 'STATUS_COLOR'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_priority ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE jira_fdw.stg_priority OWNER TO dev_user;

--
-- Name: stg_project; Type: FOREIGN TABLE; Schema: jira_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE jira_fdw.stg_project (
    "ID" double precision,
    pname text,
    "URL" text,
    "LEAD" text,
    "DESCRIPTION" text,
    pkey text,
    pcounter double precision,
    "ASSIGNEETYPE" double precision,
    "AVATAR" double precision,
    "ORIGINALKEY" text,
    "PROJECTTYPE" text,
    etl_datetime timestamp without time zone
)
SERVER staging_server
OPTIONS (
    schema_name 'src_jira',
    table_name 'stg_project'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_project ALTER COLUMN "ID" OPTIONS (
    column_name 'ID'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_project ALTER COLUMN pname OPTIONS (
    column_name 'pname'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_project ALTER COLUMN "URL" OPTIONS (
    column_name 'URL'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_project ALTER COLUMN "LEAD" OPTIONS (
    column_name 'LEAD'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_project ALTER COLUMN "DESCRIPTION" OPTIONS (
    column_name 'DESCRIPTION'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_project ALTER COLUMN pkey OPTIONS (
    column_name 'pkey'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_project ALTER COLUMN pcounter OPTIONS (
    column_name 'pcounter'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_project ALTER COLUMN "ASSIGNEETYPE" OPTIONS (
    column_name 'ASSIGNEETYPE'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_project ALTER COLUMN "AVATAR" OPTIONS (
    column_name 'AVATAR'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_project ALTER COLUMN "ORIGINALKEY" OPTIONS (
    column_name 'ORIGINALKEY'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_project ALTER COLUMN "PROJECTTYPE" OPTIONS (
    column_name 'PROJECTTYPE'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_project ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE jira_fdw.stg_project OWNER TO dev_user;

--
-- Name: stg_resolution; Type: FOREIGN TABLE; Schema: jira_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE jira_fdw.stg_resolution (
    "ID" text,
    "SEQUENCE" double precision,
    pname text,
    "DESCRIPTION" text,
    "ICONURL" text,
    etl_datetime timestamp without time zone
)
SERVER staging_server
OPTIONS (
    schema_name 'src_jira',
    table_name 'stg_resolution'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_resolution ALTER COLUMN "ID" OPTIONS (
    column_name 'ID'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_resolution ALTER COLUMN "SEQUENCE" OPTIONS (
    column_name 'SEQUENCE'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_resolution ALTER COLUMN pname OPTIONS (
    column_name 'pname'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_resolution ALTER COLUMN "DESCRIPTION" OPTIONS (
    column_name 'DESCRIPTION'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_resolution ALTER COLUMN "ICONURL" OPTIONS (
    column_name 'ICONURL'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_resolution ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE jira_fdw.stg_resolution OWNER TO dev_user;

--
-- Name: stg_worklog; Type: FOREIGN TABLE; Schema: jira_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE jira_fdw.stg_worklog (
    "ID" double precision,
    issueid double precision,
    "AUTHOR" text,
    grouplevel text,
    rolelevel text,
    worklogbody text,
    "CREATED" timestamp without time zone,
    "UPDATEAUTHOR" text,
    "UPDATED" timestamp without time zone,
    "STARTDATE" timestamp without time zone,
    timeworked double precision,
    etl_datetime timestamp without time zone
)
SERVER staging_server
OPTIONS (
    schema_name 'src_jira',
    table_name 'stg_worklog'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_worklog ALTER COLUMN "ID" OPTIONS (
    column_name 'ID'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_worklog ALTER COLUMN issueid OPTIONS (
    column_name 'issueid'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_worklog ALTER COLUMN "AUTHOR" OPTIONS (
    column_name 'AUTHOR'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_worklog ALTER COLUMN grouplevel OPTIONS (
    column_name 'grouplevel'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_worklog ALTER COLUMN rolelevel OPTIONS (
    column_name 'rolelevel'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_worklog ALTER COLUMN worklogbody OPTIONS (
    column_name 'worklogbody'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_worklog ALTER COLUMN "CREATED" OPTIONS (
    column_name 'CREATED'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_worklog ALTER COLUMN "UPDATEAUTHOR" OPTIONS (
    column_name 'UPDATEAUTHOR'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_worklog ALTER COLUMN "UPDATED" OPTIONS (
    column_name 'UPDATED'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_worklog ALTER COLUMN "STARTDATE" OPTIONS (
    column_name 'STARTDATE'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_worklog ALTER COLUMN timeworked OPTIONS (
    column_name 'timeworked'
);
ALTER FOREIGN TABLE ONLY jira_fdw.stg_worklog ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE jira_fdw.stg_worklog OWNER TO dev_user;

--
-- Name: stg_project_customer; Type: FOREIGN TABLE; Schema: jisseki_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE jisseki_fdw.stg_project_customer (
    id bigint,
    project_id bigint,
    customer_id bigint,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    etl_datetime timestamp without time zone
)
SERVER staging_server
OPTIONS (
    schema_name 'src_jisseki',
    table_name 'stg_project_customer'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_project_customer ALTER COLUMN id OPTIONS (
    column_name 'id'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_project_customer ALTER COLUMN project_id OPTIONS (
    column_name 'project_id'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_project_customer ALTER COLUMN customer_id OPTIONS (
    column_name 'customer_id'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_project_customer ALTER COLUMN created_at OPTIONS (
    column_name 'created_at'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_project_customer ALTER COLUMN updated_at OPTIONS (
    column_name 'updated_at'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_project_customer ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE jisseki_fdw.stg_project_customer OWNER TO dev_user;

--
-- Name: stg_projects; Type: FOREIGN TABLE; Schema: jisseki_fdw; Owner: dev_user
--

CREATE FOREIGN TABLE jisseki_fdw.stg_projects (
    id bigint,
    name text,
    name_pm text,
    name_br_se text,
    code text,
    location text,
    scope text,
    type text,
    point_css double precision,
    point_comment text,
    url_1 text,
    description_1 text,
    url_2 text,
    description_2 text,
    url_3 text,
    description_3 text,
    url_4 text,
    description_4 text,
    amount text,
    report_file text,
    content_report text,
    summary text,
    "linkThumb" text,
    size double precision,
    period double precision,
    status bigint,
    active bigint,
    free_text_flag bigint,
    free_text text,
    project_rank bigint,
    team_size text,
    "startDate" timestamp without time zone,
    "endDate" timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    summary_en text,
    summary_jp text,
    etl_datetime timestamp without time zone
)
SERVER staging_server
OPTIONS (
    schema_name 'src_jisseki',
    table_name 'stg_projects'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN id OPTIONS (
    column_name 'id'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN name OPTIONS (
    column_name 'name'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN name_pm OPTIONS (
    column_name 'name_pm'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN name_br_se OPTIONS (
    column_name 'name_br_se'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN code OPTIONS (
    column_name 'code'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN location OPTIONS (
    column_name 'location'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN scope OPTIONS (
    column_name 'scope'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN type OPTIONS (
    column_name 'type'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN point_css OPTIONS (
    column_name 'point_css'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN point_comment OPTIONS (
    column_name 'point_comment'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN url_1 OPTIONS (
    column_name 'url_1'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN description_1 OPTIONS (
    column_name 'description_1'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN url_2 OPTIONS (
    column_name 'url_2'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN description_2 OPTIONS (
    column_name 'description_2'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN url_3 OPTIONS (
    column_name 'url_3'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN description_3 OPTIONS (
    column_name 'description_3'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN url_4 OPTIONS (
    column_name 'url_4'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN description_4 OPTIONS (
    column_name 'description_4'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN amount OPTIONS (
    column_name 'amount'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN report_file OPTIONS (
    column_name 'report_file'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN content_report OPTIONS (
    column_name 'content_report'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN summary OPTIONS (
    column_name 'summary'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN "linkThumb" OPTIONS (
    column_name 'linkThumb'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN size OPTIONS (
    column_name 'size'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN period OPTIONS (
    column_name 'period'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN status OPTIONS (
    column_name 'status'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN active OPTIONS (
    column_name 'active'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN free_text_flag OPTIONS (
    column_name 'free_text_flag'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN free_text OPTIONS (
    column_name 'free_text'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN project_rank OPTIONS (
    column_name 'project_rank'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN team_size OPTIONS (
    column_name 'team_size'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN "startDate" OPTIONS (
    column_name 'startDate'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN "endDate" OPTIONS (
    column_name 'endDate'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN created_at OPTIONS (
    column_name 'created_at'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN updated_at OPTIONS (
    column_name 'updated_at'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN summary_en OPTIONS (
    column_name 'summary_en'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN summary_jp OPTIONS (
    column_name 'summary_jp'
);
ALTER FOREIGN TABLE ONLY jisseki_fdw.stg_projects ALTER COLUMN etl_datetime OPTIONS (
    column_name 'etl_datetime'
);


ALTER FOREIGN TABLE jisseki_fdw.stg_projects OWNER TO dev_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: billable_efforts_approveds; Type: TABLE; Schema: public; Owner: dev_user
--

CREATE TABLE public.billable_efforts_approveds (
    effort_id text,
    user_id text,
    pod_id text,
    department_id text,
    effort double precision,
    month_year text,
    user_role text,
    status text,
    is_deleted text,
    created_time timestamp with time zone,
    updated_time timestamp with time zone,
    etl_datetime timestamp with time zone
);


ALTER TABLE public.billable_efforts_approveds OWNER TO dev_user;

--
-- Name: branches; Type: TABLE; Schema: public; Owner: dev_user
--

CREATE TABLE public.branches (
    branch_id text,
    branch_code text,
    branch_name text,
    branch_address text,
    is_hidden text,
    status text,
    is_deleted text,
    created_time timestamp with time zone,
    etl_datetime timestamp with time zone
);


ALTER TABLE public.branches OWNER TO dev_user;

--
-- Name: departments; Type: TABLE; Schema: public; Owner: dev_user
--

CREATE TABLE public.departments (
    department_id text,
    branch_id text,
    department_name text,
    level bigint,
    children text,
    parent_id text,
    status text,
    is_deleted text,
    updated_time timestamp with time zone,
    etl_datetime timestamp with time zone
);


ALTER TABLE public.departments OWNER TO dev_user;

--
-- Name: jira_issue_priority; Type: TABLE; Schema: public; Owner: dev_user
--

CREATE TABLE public.jira_issue_priority (
    priority_id text,
    priority_name text,
    priority_description text,
    etl_datetime timestamp with time zone
);


ALTER TABLE public.jira_issue_priority OWNER TO dev_user;

--
-- Name: jira_issue_resolution; Type: TABLE; Schema: public; Owner: dev_user
--

CREATE TABLE public.jira_issue_resolution (
    resolution_id text,
    resolution_name text,
    resolution_description text,
    etl_datetime timestamp with time zone
);


ALTER TABLE public.jira_issue_resolution OWNER TO dev_user;

--
-- Name: jira_issue_status; Type: TABLE; Schema: public; Owner: dev_user
--

CREATE TABLE public.jira_issue_status (
    status_id text,
    status_name text,
    status_description text,
    etl_datetime timestamp with time zone
);


ALTER TABLE public.jira_issue_status OWNER TO dev_user;

--
-- Name: jira_issue_types; Type: TABLE; Schema: public; Owner: dev_user
--

CREATE TABLE public.jira_issue_types (
    type_id text,
    type_name text,
    type_description text,
    etl_datetime timestamp with time zone
);


ALTER TABLE public.jira_issue_types OWNER TO dev_user;

--
-- Name: jira_issues; Type: TABLE; Schema: public; Owner: dev_user
--

CREATE TABLE public.jira_issues (
    issue_id double precision,
    issue_number double precision,
    jira_project_id double precision,
    issue_type text,
    issue_reporter text,
    issue_assignee text,
    issue_creator text,
    issue_summary text,
    issue_description text,
    issue_priority text,
    issue_resolution text,
    resolution_date timestamp without time zone,
    issue_status text,
    due_date timestamp without time zone,
    time_original_estimate double precision,
    time_estimate double precision,
    time_spent double precision,
    environment text,
    created_time timestamp without time zone,
    updated_time timestamp without time zone,
    etl_datetime timestamp with time zone
);


ALTER TABLE public.jira_issues OWNER TO dev_user;

--
-- Name: jira_worklog; Type: TABLE; Schema: public; Owner: dev_user
--

CREATE TABLE public.jira_worklog (
    worklog_id double precision,
    issue_id double precision,
    worklog_author text,
    worklog_description text,
    start_time timestamp without time zone,
    time_worked double precision,
    update_author text,
    created_time timestamp without time zone,
    updated_time timestamp without time zone,
    etl_datetime timestamp with time zone
);


ALTER TABLE public.jira_worklog OWNER TO dev_user;

--
-- Name: pods; Type: TABLE; Schema: public; Owner: dev_user
--

CREATE TABLE public.pods (
    pod_id text,
    project_code text,
    project_name text,
    project_type text,
    project_size text,
    project_rank text,
    project_overview text,
    project_category text,
    warranty_condition text,
    development_model text,
    department_id text,
    jira_url text,
    start_date timestamp with time zone,
    plan_uat_date timestamp with time zone,
    plan_release_date timestamp with time zone,
    final_release_date timestamp with time zone,
    pod_status text,
    status text,
    is_deleted text,
    created_time timestamp with time zone,
    updated_time timestamp with time zone,
    etl_datetime timestamp with time zone
);


ALTER TABLE public.pods OWNER TO dev_user;

--
-- Name: project_members; Type: TABLE; Schema: public; Owner: dev_user
--

CREATE TABLE public.project_members (
    project_id text,
    user_id text,
    joined_at timestamp with time zone,
    left_at timestamp with time zone,
    status text,
    is_deleted text,
    user_level double precision,
    updated_time timestamp with time zone,
    etl_datetime timestamp with time zone
);


ALTER TABLE public.project_members OWNER TO dev_user;

--
-- Name: project_profit_loss; Type: TABLE; Schema: public; Owner: dev_user
--

CREATE TABLE public.project_profit_loss (
    project_id text,
    user_id text,
    department_id text,
    branch_id text,
    value double precision,
    value1 bigint,
    status text,
    is_deleted text,
    month_at text,
    updated_time timestamp with time zone,
    etl_datetime timestamp with time zone
);


ALTER TABLE public.project_profit_loss OWNER TO dev_user;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: dev_user
--

CREATE TABLE public.projects (
    project_id text,
    jira_project_id double precision,
    project_name text,
    project_jira_url text,
    project_description text,
    project_lead text,
    project_code text,
    project_status text,
    project_type text,
    is_deleted text,
    name_pm text,
    name_brse text,
    location text,
    scope text,
    type text,
    point_css double precision,
    point_comment text,
    summary text,
    size double precision,
    period double precision,
    project_rank bigint,
    team_size text,
    start_date timestamp without time zone,
    end_date timestamp without time zone,
    updated_time timestamp without time zone,
    etl_datetime timestamp with time zone
);


ALTER TABLE public.projects OWNER TO dev_user;

--
-- Name: salaries; Type: TABLE; Schema: public; Owner: dev_user
--

CREATE TABLE public.salaries (
    salary_id text,
    user_id text,
    insurance text,
    basic_salary text,
    total_salary text,
    is_deleted text,
    status text,
    user_info_block text,
    created_time timestamp with time zone,
    updated_time timestamp with time zone,
    etl_datetime timestamp with time zone
);


ALTER TABLE public.salaries OWNER TO dev_user;

--
-- Name: staff_attendances; Type: TABLE; Schema: public; Owner: dev_user
--

CREATE TABLE public.staff_attendances (
    attendance_id text,
    user_id text,
    attendance_type_id text,
    from_date timestamp with time zone,
    end_date timestamp with time zone,
    absent_day double precision,
    absent_reason text,
    status_approval text,
    date_approval timestamp with time zone,
    type text,
    status text,
    is_deleted text,
    created_time timestamp with time zone,
    updated_time timestamp with time zone,
    etl_datetime timestamp with time zone
);


ALTER TABLE public.staff_attendances OWNER TO dev_user;

--
-- Name: staff_attendances_types; Type: TABLE; Schema: public; Owner: dev_user
--

CREATE TABLE public.staff_attendances_types (
    attendance_type_id text,
    attendance_type_name text,
    attendance_type_code text,
    attendance_work_day bigint,
    status text,
    is_deleted text,
    type text,
    unit_status text,
    unit_type text,
    unit_value double precision,
    created_time timestamp with time zone,
    updated_time timestamp with time zone,
    etl_datetime timestamp with time zone
);


ALTER TABLE public.staff_attendances_types OWNER TO dev_user;

--
-- Name: time_series; Type: TABLE; Schema: public; Owner: dev_user
--

CREATE TABLE public.time_series (
    time_id integer NOT NULL,
    date date NOT NULL,
    year integer,
    month integer,
    month_name character varying(10),
    quarter integer,
    is_month_end boolean
);


ALTER TABLE public.time_series OWNER TO dev_user;

--
-- Name: time_series_time_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_user
--

CREATE SEQUENCE public.time_series_time_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.time_series_time_id_seq OWNER TO dev_user;

--
-- Name: time_series_time_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_user
--

ALTER SEQUENCE public.time_series_time_id_seq OWNED BY public.time_series.time_id;


--
-- Name: user_positions; Type: TABLE; Schema: public; Owner: dev_user
--

CREATE TABLE public.user_positions (
    position_id text,
    position_code text,
    position_name text,
    position_level double precision,
    position_description text,
    position_status text,
    position_type text,
    status text,
    is_deleted text,
    updated_time text,
    etl_datetime timestamp with time zone
);


ALTER TABLE public.user_positions OWNER TO dev_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: dev_user
--

CREATE TABLE public.users (
    user_id text,
    user_name text,
    birthday date,
    address text,
    gender text,
    personal_email text,
    mobile text,
    username text,
    password text,
    company_email text,
    staff_code double precision,
    branch_id text,
    department_id text,
    position_id text,
    welcome_day date,
    probation_date date,
    quit_date date,
    user_level text,
    user_status text,
    is_deleted text,
    etl_datetime timestamp with time zone
);


ALTER TABLE public.users OWNER TO dev_user;

--
-- Name: time_series time_id; Type: DEFAULT; Schema: public; Owner: dev_user
--

ALTER TABLE ONLY public.time_series ALTER COLUMN time_id SET DEFAULT nextval('public.time_series_time_id_seq'::regclass);


--
-- Name: time_series time_series_pkey; Type: CONSTRAINT; Schema: public; Owner: dev_user
--

ALTER TABLE ONLY public.time_series
    ADD CONSTRAINT time_series_pkey PRIMARY KEY (time_id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: dev_user
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

--
-- Database "monitoring" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 14.18
-- Dumped by pg_dump version 17.5 (Debian 17.5-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: monitoring; Type: DATABASE; Schema: -; Owner: dev_user
--

CREATE DATABASE monitoring WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE monitoring OWNER TO dev_user;

\connect monitoring

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: dev_user
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO dev_user;

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: etl_job_logs; Type: TABLE; Schema: public; Owner: dev_user
--

CREATE TABLE public.etl_job_logs (
    id integer NOT NULL,
    job_name character varying(255),
    source_db character varying(255),
    target_db character varying(255),
    source_table jsonb,
    target_table character varying(255),
    dag_id character varying(255),
    task_id character varying(255),
    execution_time timestamp without time zone,
    status character varying(50),
    created_time timestamp without time zone
);


ALTER TABLE public.etl_job_logs OWNER TO dev_user;

--
-- Name: etl_job_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_user
--

CREATE SEQUENCE public.etl_job_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.etl_job_logs_id_seq OWNER TO dev_user;

--
-- Name: etl_job_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_user
--

ALTER SEQUENCE public.etl_job_logs_id_seq OWNED BY public.etl_job_logs.id;


--
-- Name: etl_job_logs id; Type: DEFAULT; Schema: public; Owner: dev_user
--

ALTER TABLE ONLY public.etl_job_logs ALTER COLUMN id SET DEFAULT nextval('public.etl_job_logs_id_seq'::regclass);


--
-- Name: etl_job_logs etl_job_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: dev_user
--

ALTER TABLE ONLY public.etl_job_logs
    ADD CONSTRAINT etl_job_logs_pkey PRIMARY KEY (id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: dev_user
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

-- Dumped from database version 14.18
-- Dumped by pg_dump version 17.5 (Debian 17.5-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: dev_user
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO dev_user;

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: dev_user
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

--
-- Database "stg" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 14.18
-- Dumped by pg_dump version 17.5 (Debian 17.5-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: stg; Type: DATABASE; Schema: -; Owner: dev_user
--

CREATE DATABASE stg WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE stg OWNER TO dev_user;

\connect stg

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: dev_user
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO dev_user;

--
-- Name: src_create; Type: SCHEMA; Schema: -; Owner: dev_user
--

CREATE SCHEMA src_create;


ALTER SCHEMA src_create OWNER TO dev_user;

--
-- Name: src_jira; Type: SCHEMA; Schema: -; Owner: dev_user
--

CREATE SCHEMA src_jira;


ALTER SCHEMA src_jira OWNER TO dev_user;

--
-- Name: src_jisseki; Type: SCHEMA; Schema: -; Owner: dev_user
--

CREATE SCHEMA src_jisseki;


ALTER SCHEMA src_jisseki OWNER TO dev_user;

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: stg_billable_efforts_approveds; Type: TABLE; Schema: src_create; Owner: dev_user
--

CREATE TABLE src_create.stg_billable_efforts_approveds (
    _id text,
    "employeeObjId" text,
    month text,
    "pODObjId" text,
    "rowKey" text,
    year text,
    "createdAt" text,
    "createdBy" text,
    "departmentObjId" text,
    effort double precision,
    "isDeleted" text,
    note text,
    role text,
    status text,
    "updatedAt" text,
    "updatedBy" text,
    "departmentVendor" text,
    "isVendor" boolean,
    type text,
    username text,
    etl_datetime timestamp without time zone
);


ALTER TABLE src_create.stg_billable_efforts_approveds OWNER TO dev_user;

--
-- Name: stg_branches; Type: TABLE; Schema: src_create; Owner: dev_user
--

CREATE TABLE src_create.stg_branches (
    _id text,
    "branchAddress" text,
    status text,
    "order" bigint,
    "isDeleted" text,
    "branchName" text,
    "branchCode" text,
    "createdAt" text,
    "createdBy" text,
    "isHidden" text,
    etl_datetime timestamp without time zone
);


ALTER TABLE src_create.stg_branches OWNER TO dev_user;

--
-- Name: stg_company_departments; Type: TABLE; Schema: src_create; Owner: dev_user
--

CREATE TABLE src_create.stg_company_departments (
    _id text,
    "departmentCode" text,
    "departmentDescription" text,
    level bigint,
    children text,
    "departmentType" text,
    status text,
    "order" double precision,
    "isDeleted" text,
    "departmentName" text,
    "parentObjId" text,
    "departmentTypeObjId" text,
    note text,
    "createdAt" text,
    "createdBy" text,
    "branchObjId" text,
    "isHidden" text,
    "accessedDepartments" text,
    "updatedAt" text,
    "updatedBy" text,
    "MISACode" text,
    "OrganizationUnitId" text,
    "OrganizationUnitName" text,
    "managerObjId" text,
    "departmentTypeLevel" text,
    etl_datetime timestamp without time zone
);


ALTER TABLE src_create.stg_company_departments OWNER TO dev_user;

--
-- Name: stg_pods; Type: TABLE; Schema: src_create; Owner: dev_user
--

CREATE TABLE src_create.stg_pods (
    _id text,
    "projectCode" text,
    "projectName" text,
    "projectType" text,
    "projectSize" text,
    "projectRank" text,
    "startDate" text,
    "planUATDate" text,
    "planReleaseDate" text,
    "finalReleaseDate" text,
    "warrantyCondition" text,
    "projectOverview" text,
    "developmentModel" text,
    "jiraUrl" text,
    "weUrl" text,
    "gitUrl" text,
    "statusPOD" text,
    status text,
    "order" bigint,
    "isDeleted" text,
    "departmentObjId" text,
    "pmObjId" text,
    "saleObjId" text,
    "customerObjId" text,
    domain text,
    "createdAt" text,
    "createdBy" text,
    "updatedAt" text,
    "updatedBy" double precision,
    "referList" text,
    "marketObjId" text,
    "projectCategory" text,
    "subPmObjId" text,
    etl_datetime timestamp without time zone
);


ALTER TABLE src_create.stg_pods OWNER TO dev_user;

--
-- Name: stg_profit_loss_expenses; Type: TABLE; Schema: src_create; Owner: dev_user
--

CREATE TABLE src_create.stg_profit_loss_expenses (
    _id text,
    "staffCode" text,
    "branchObjId" text,
    "departmentObjId" text,
    "userObjId" text,
    "profitType" text,
    "projectObjId" text,
    "profitLossInvoiceObjId" text,
    value double precision,
    value1 bigint,
    description text,
    type text,
    "infoOther" text,
    "userPositionObjId" text,
    "userLevel" text,
    status text,
    "order" bigint,
    "isDeleted" text,
    "monthAt" text,
    "configCode" text,
    "closingMonthObjId" text,
    "configObjId" text,
    "createdAt" text,
    "createdBy" text,
    info text,
    etl_datetime timestamp without time zone
);


ALTER TABLE src_create.stg_profit_loss_expenses OWNER TO dev_user;

--
-- Name: stg_profit_loss_project_expenses; Type: TABLE; Schema: src_create; Owner: dev_user
--

CREATE TABLE src_create.stg_profit_loss_project_expenses (
    _id text,
    "staffCode" double precision,
    "branchObjId" text,
    "departmentObjId" text,
    "userObjId" text,
    "profitLossInvoiceObjId" text,
    value double precision,
    value1 bigint,
    description text,
    type text,
    status text,
    "order" bigint,
    "isDeleted" text,
    "monthAt" text,
    "configCode" text,
    "projectObjId" text,
    "closingMonthObjId" text,
    "configObjId" text,
    "createdAt" text,
    "createdBy" text,
    "updatedAt" text,
    "updatedBy" text,
    info text,
    etl_datetime timestamp without time zone
);


ALTER TABLE src_create.stg_profit_loss_project_expenses OWNER TO dev_user;

--
-- Name: stg_project_categories; Type: TABLE; Schema: src_create; Owner: dev_user
--

CREATE TABLE src_create.stg_project_categories (
    _id text,
    note text,
    status text,
    "order" bigint,
    "isDeleted" text,
    "projectCategoryName" text,
    "projectCategoryDescription" text,
    "projectCategoryJiraUrl" text,
    "createdAt" text,
    "createdBy" text,
    "jiraCategoryId" bigint,
    "updatedAt" text,
    "updatedBy" text,
    "jiraType" text,
    etl_datetime timestamp without time zone
);


ALTER TABLE src_create.stg_project_categories OWNER TO dev_user;

--
-- Name: stg_project_members; Type: TABLE; Schema: src_create; Owner: dev_user
--

CREATE TABLE src_create.stg_project_members (
    _id text,
    "projectPositionObjIds" text,
    note text,
    status text,
    "order" bigint,
    "isDeleted" text,
    "projectObjId" text,
    "userObjId" text,
    description text,
    "joinedAt" text,
    "leftAt" text,
    "createdAt" text,
    "updatedAt" text,
    "updatedBy" text,
    "createdBy" text,
    level double precision,
    etl_datetime timestamp without time zone
);


ALTER TABLE src_create.stg_project_members OWNER TO dev_user;

--
-- Name: stg_projects; Type: TABLE; Schema: src_create; Owner: dev_user
--

CREATE TABLE src_create.stg_projects (
    _id text,
    "projectCategoryObjId" text,
    note text,
    status text,
    "order" bigint,
    "isDeleted" text,
    "projectName" text,
    "projectCode" text,
    "projectStatus" text,
    "projectJiraUrl" text,
    "projectDescription" text,
    "createdAt" text,
    "createdBy" text,
    "jiraProjectId" double precision,
    "jiraProjectKey" text,
    "projectType" text,
    "jiraType" text,
    "projectLeadObjId" text,
    "updatedAt" text,
    "updatedBy" text,
    type text,
    "flagCron" text,
    "dataType" text,
    "projectTypeKeyJira" text,
    "projectCustomerCode" double precision,
    "projectObjective" text,
    "projectOverView" text,
    "projectRank" text,
    "projectScope" text,
    "totalBillEffort" double precision,
    "totalIntBillEffort" double precision,
    "endAt" text,
    "startAt" text,
    "releaseAt" text,
    "podLink" text,
    "podWe" text,
    "projectDiv" double precision,
    "projectChildObjIds" text,
    etl_datetime timestamp without time zone
);


ALTER TABLE src_create.stg_projects OWNER TO dev_user;

--
-- Name: stg_salaries; Type: TABLE; Schema: src_create; Owner: dev_user
--

CREATE TABLE src_create.stg_salaries (
    _id text,
    "closingMonthObjId" text,
    "userObjId" text,
    "createdAt" text,
    "createdBy" text,
    insurance text,
    "isDeleted" text,
    "order" bigint,
    "salaryBasic" text,
    status text,
    "totalSalary" text,
    "updatedBy" text,
    "userInfoBlock" text,
    "editUserObjId" text,
    "updatedAt" text,
    note text,
    etl_datetime timestamp without time zone
);


ALTER TABLE src_create.stg_salaries OWNER TO dev_user;

--
-- Name: stg_staff_attendance_types; Type: TABLE; Schema: src_create; Owner: dev_user
--

CREATE TABLE src_create.stg_staff_attendance_types (
    _id text,
    "attendanceTypeName" text,
    "attendanceTypeCode" text,
    "attendanceWorkDay" bigint,
    "attendanceTypeID" text,
    status text,
    "order" bigint,
    "isDeleted" text,
    "createdAt" text,
    "createdBy" text,
    "isUsed" text,
    type text,
    "unitStatus" text,
    "unitType" text,
    "unitValue" double precision,
    "updatedAt" text,
    "updatedBy" text,
    "attendanceName" text,
    note text,
    etl_datetime timestamp without time zone
);


ALTER TABLE src_create.stg_staff_attendance_types OWNER TO dev_user;

--
-- Name: stg_staff_attendances; Type: TABLE; Schema: src_create; Owner: dev_user
--

CREATE TABLE src_create.stg_staff_attendances (
    _id text,
    "relationshipObjIds" text,
    "substituteObjId" text,
    "fromDate" text,
    "endDate" text,
    "absentDay" double precision,
    reason text,
    "statusApproval" text,
    "dateApproval" text,
    comment text,
    "attendanceID" text,
    type text,
    "lateInFirstHalfShift" double precision,
    "earlyOutFirstHaftShift" text,
    "lateInLastHalfShift" text,
    "earlyOutLastHalfShift" double precision,
    "applyFor" text,
    status text,
    "order" bigint,
    "isDeleted" text,
    "userObjId" text,
    "attendanceTypeObjId" text,
    "reportObjId" text,
    "createdAt" text,
    "createdBy" text,
    "flagCron" text,
    "leavesApproval" double precision,
    "attendanceState" text,
    "flagCrawler" text,
    "absentDayPresent" double precision,
    "absentDayFuture" double precision,
    "absentDayDetail" text,
    note text,
    "userApprovalObjId" text,
    "remainDay" double precision,
    "leftDay" double precision,
    "totalLeaveDay" double precision,
    "updatedAt" text,
    "updatedBy" text,
    "totalLeaveDayRaw" double precision,
    "leftDayRaw" double precision,
    "remainDayRaw" double precision,
    etl_datetime timestamp without time zone
);


ALTER TABLE src_create.stg_staff_attendances OWNER TO dev_user;

--
-- Name: stg_user_infos; Type: TABLE; Schema: src_create; Owner: dev_user
--

CREATE TABLE src_create.stg_user_infos (
    _id text,
    "staffCode" double precision,
    "firstName" text,
    "middleName" text,
    "lastName" text,
    "emailCompany" text,
    "emailPersonal" text,
    "birthDay" text,
    "welcomeDay" double precision,
    gender text,
    "mobileCountryCode" text,
    mobile text,
    "officeTel" text,
    address text,
    note text,
    "userJobStatus" text,
    status text,
    "order" bigint,
    "isDeleted" text,
    "userObjId" text,
    "createdAt" text,
    "createdBy" text,
    "updatedAt" text,
    "updatedBy" text,
    "employeeID" text,
    "flagCron" text,
    "officialDate" text,
    "probationDate" text,
    "organizationUnitID" text,
    "organizationUnitName" text,
    "internDate" text,
    "dataType" text,
    "MISACode" text,
    "quitDate" text,
    "timekeepingDate" text,
    "welcomeDate" text,
    etl_datetime timestamp without time zone
);


ALTER TABLE src_create.stg_user_infos OWNER TO dev_user;

--
-- Name: stg_user_positions; Type: TABLE; Schema: src_create; Owner: dev_user
--

CREATE TABLE src_create.stg_user_positions (
    _id text,
    status text,
    "order" bigint,
    "isDeleted" text,
    "positionName" text,
    "positionCode" text,
    "positionDescription" text,
    "createdAt" text,
    "createdBy" text,
    "updatedAt" text,
    "updatedBy" text,
    "positionStatus" text,
    "positionLevel" double precision,
    "eLearningGroupPositionObjId" text,
    type text,
    etl_datetime timestamp without time zone
);


ALTER TABLE src_create.stg_user_positions OWNER TO dev_user;

--
-- Name: stg_user_skills; Type: TABLE; Schema: src_create; Owner: dev_user
--

CREATE TABLE src_create.stg_user_skills (
    _id text,
    status text,
    "order" bigint,
    "isDeleted" text,
    "userObjId" text,
    "userSkills" text,
    "createdAt" text,
    "createdBy" text,
    etl_datetime timestamp without time zone
);


ALTER TABLE src_create.stg_user_skills OWNER TO dev_user;

--
-- Name: stg_users; Type: TABLE; Schema: src_create; Owner: dev_user
--

CREATE TABLE src_create.stg_users (
    _id text,
    uid text,
    name text,
    "branchObjId" text,
    "userPositionObjId" text,
    mobile double precision,
    jira_user_id double precision,
    note text,
    status text,
    "order" bigint,
    "isDeleted" text,
    username text,
    password text,
    email text,
    "createdAt" text,
    "createdBy" text,
    "staffCode" double precision,
    "mobileCountryCode" double precision,
    "departmentObjId" text,
    "positionObjId" text,
    "updatedAt" text,
    "updatedBy" text,
    "userType" text,
    "userJiraMapping" text,
    "welcomeDay" text,
    "userStatus" text,
    "expiresDate" text,
    "userCode" text,
    "flagCron" text,
    "countFailed" double precision,
    "resetToken" text,
    "nameTag" text,
    level double precision,
    "userLevel" text,
    "userUpdatedAt" text,
    "userSubPositionObjId" text,
    "performanceFactor" double precision,
    "jobObjId" double precision,
    "userJobStatus" text,
    "jiraUserId" double precision,
    "jiraName" text,
    "birthDay" double precision,
    "emailPersonal" double precision,
    gender double precision,
    etl_datetime timestamp without time zone
);


ALTER TABLE src_create.stg_users OWNER TO dev_user;

--
-- Name: stg_issuestatus; Type: TABLE; Schema: src_jira; Owner: dev_user
--

CREATE TABLE src_jira.stg_issuestatus (
    "ID" text,
    "SEQUENCE" double precision,
    pname text,
    "DESCRIPTION" text,
    "ICONURL" text,
    "STATUSCATEGORY" double precision,
    etl_datetime timestamp without time zone
);


ALTER TABLE src_jira.stg_issuestatus OWNER TO dev_user;

--
-- Name: stg_issuetype; Type: TABLE; Schema: src_jira; Owner: dev_user
--

CREATE TABLE src_jira.stg_issuetype (
    "ID" text,
    "SEQUENCE" double precision,
    pname text,
    pstyle text,
    "DESCRIPTION" text,
    "ICONURL" text,
    "AVATAR" double precision,
    etl_datetime timestamp without time zone
);


ALTER TABLE src_jira.stg_issuetype OWNER TO dev_user;

--
-- Name: stg_jiraissue; Type: TABLE; Schema: src_jira; Owner: dev_user
--

CREATE TABLE src_jira.stg_jiraissue (
    "ID" double precision,
    pkey text,
    issuenum double precision,
    "PROJECT" double precision,
    "REPORTER" text,
    "ASSIGNEE" text,
    "CREATOR" text,
    issuetype text,
    "SUMMARY" text,
    "DESCRIPTION" text,
    "ENVIRONMENT" text,
    "PRIORITY" text,
    "RESOLUTION" text,
    issuestatus text,
    "CREATED" timestamp without time zone,
    "UPDATED" timestamp without time zone,
    "DUEDATE" timestamp without time zone,
    "RESOLUTIONDATE" timestamp without time zone,
    "VOTES" double precision,
    "WATCHES" double precision,
    "TIMEORIGINALESTIMATE" double precision,
    "TIMEESTIMATE" double precision,
    "TIMESPENT" double precision,
    "WORKFLOW_ID" double precision,
    "SECURITY" double precision,
    "FIXFOR" text,
    "COMPONENT" text,
    "ARCHIVED" text,
    "ARCHIVEDBY" text,
    "ARCHIVEDDATE" text,
    etl_datetime timestamp without time zone
);


ALTER TABLE src_jira.stg_jiraissue OWNER TO dev_user;

--
-- Name: stg_priority; Type: TABLE; Schema: src_jira; Owner: dev_user
--

CREATE TABLE src_jira.stg_priority (
    "ID" text,
    "SEQUENCE" double precision,
    pname text,
    "DESCRIPTION" text,
    "ICONURL" text,
    "STATUS_COLOR" text,
    etl_datetime timestamp without time zone
);


ALTER TABLE src_jira.stg_priority OWNER TO dev_user;

--
-- Name: stg_project; Type: TABLE; Schema: src_jira; Owner: dev_user
--

CREATE TABLE src_jira.stg_project (
    "ID" double precision,
    pname text,
    "URL" text,
    "LEAD" text,
    "DESCRIPTION" text,
    pkey text,
    pcounter double precision,
    "ASSIGNEETYPE" double precision,
    "AVATAR" double precision,
    "ORIGINALKEY" text,
    "PROJECTTYPE" text,
    etl_datetime timestamp without time zone
);


ALTER TABLE src_jira.stg_project OWNER TO dev_user;

--
-- Name: stg_resolution; Type: TABLE; Schema: src_jira; Owner: dev_user
--

CREATE TABLE src_jira.stg_resolution (
    "ID" text,
    "SEQUENCE" double precision,
    pname text,
    "DESCRIPTION" text,
    "ICONURL" text,
    etl_datetime timestamp without time zone
);


ALTER TABLE src_jira.stg_resolution OWNER TO dev_user;

--
-- Name: stg_worklog; Type: TABLE; Schema: src_jira; Owner: dev_user
--

CREATE TABLE src_jira.stg_worklog (
    "ID" double precision,
    issueid double precision,
    "AUTHOR" text,
    grouplevel text,
    rolelevel text,
    worklogbody text,
    "CREATED" timestamp without time zone,
    "UPDATEAUTHOR" text,
    "UPDATED" timestamp without time zone,
    "STARTDATE" timestamp without time zone,
    timeworked double precision,
    etl_datetime timestamp without time zone
);


ALTER TABLE src_jira.stg_worklog OWNER TO dev_user;

--
-- Name: stg_project_customer; Type: TABLE; Schema: src_jisseki; Owner: dev_user
--

CREATE TABLE src_jisseki.stg_project_customer (
    id bigint,
    project_id bigint,
    customer_id bigint,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    etl_datetime timestamp without time zone
);


ALTER TABLE src_jisseki.stg_project_customer OWNER TO dev_user;

--
-- Name: stg_projects; Type: TABLE; Schema: src_jisseki; Owner: dev_user
--

CREATE TABLE src_jisseki.stg_projects (
    id bigint,
    name text,
    name_pm text,
    name_br_se text,
    code text,
    location text,
    scope text,
    type text,
    point_css double precision,
    point_comment text,
    url_1 text,
    description_1 text,
    url_2 text,
    description_2 text,
    url_3 text,
    description_3 text,
    url_4 text,
    description_4 text,
    amount text,
    report_file text,
    content_report text,
    summary text,
    "linkThumb" text,
    size double precision,
    period double precision,
    status bigint,
    active bigint,
    free_text_flag bigint,
    free_text text,
    project_rank bigint,
    team_size text,
    "startDate" timestamp without time zone,
    "endDate" timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    summary_en text,
    summary_jp text,
    etl_datetime timestamp without time zone
);


ALTER TABLE src_jisseki.stg_projects OWNER TO dev_user;

--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: dev_user
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database cluster dump complete
--

